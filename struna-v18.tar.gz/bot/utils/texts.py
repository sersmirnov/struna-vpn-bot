"""All bot texts / messages. Single source of truth for copy."""


WELCOME = """🎸 <b>Добро пожаловать в StrunaVPN!</b>

Быстрый и надёжный VPN прямо в Telegram.
Обход блокировок в 2 клика.

🔒 <b>Как это работает?</b>
Мы используем протокол, который невозможно заблокировать. Вы получите VPN-ключ и вставите его в бесплатное приложение Hiddify — всё займёт 2 минуты.

🎁 <b>Бесплатно:</b> 7 дней безлимитного VPN!

Нажми кнопку ниже, чтобы начать 👇"""

WELCOME_REFERRED = """🎸 <b>Добро пожаловать в StrunaVPN!</b>

Вас пригласил друг — вы получаете <b>{days} дней бесплатного VPN!</b> 🎉

🔒 <b>Как это работает?</b>
Мы используем протокол, который невозможно заблокировать. Вы получите VPN-ключ и вставите его в бесплатное приложение Hiddify — всё займёт 2 минуты.

Нажмите кнопку ниже, чтобы получить VPN-ключ 👇"""

# === Main Menu ===
MENU = """🎸 <b>StrunaVPN — Главное меню</b>

Выберите действие:"""

# === Subscription ===
SUB_STATUS_FREE = """📦 <b>Ваша подписка: Free (пробный период)</b>

├ Трафик: безлимит
├ Устройства: 2
└ Действует до: <b>{expires}</b>

💡 <i>Перейдите на Basic для 5 устройств и 30 дней!</i>"""

SUB_STATUS_PAID = """📦 <b>Ваша подписка: {plan}</b>

├ Трафик: безлимит
├ Устройства: {devices}
├ Скорость: максимальная
└ Действует до: <b>{expires}</b>"""

SUB_KEY_INTRO = """⬇️ <b>Ваша ссылка для подключения — нажмите чтобы скопировать:</b>"""

SUB_KEY_COPY = "<code>{key}</code>"

SUB_KEY_INSTRUCTIONS = """✅ <b>Скопировали? Отлично!</b>

📲 <b>Что дальше:</b>
1. Скачайте <b>Hiddify</b> (бесплатно):
   • <a href="https://play.google.com/store/apps/details?id=app.hiddify.com">Android</a> | <a href="https://apps.apple.com/app/hiddify-proxy-vpn/id6596777532">iPhone</a> | <a href="https://github.com/hiddify/hiddify-app/releases">Windows/Mac</a>
2. Откройте Hiddify → нажмите <b>+</b> → <b>Clipboard</b>
3. Нажмите <b>Tap to connect</b> ✅

🌍 В Hiddify будут доступны серверы: Финляндия 🇫🇮 и Германия 🇩🇪 — выбирайте ближайший!

💡 Не работает? Нажмите «💬 Поддержка» в меню."""

SUB_NO_KEY = """⚠️ У вас пока нет VPN-ключа.
Нажмите «🔑 Получить ключ» чтобы создать его."""

# === Payment ===
PLANS_LIST = """🛒 <b>Тарифные планы StrunaVPN</b>

┌─ 🆓 <b>Free</b> — бесплатно
│  7 дней, 2 устройства
│
└─ ⭐ <b>Basic</b> — {basic_price} Stars (~100₽/мес)
   30 дней, 5 устройств

Выберите тариф:"""

PAYMENT_INVOICE_TITLE = "StrunaVPN — {plan}"
PAYMENT_INVOICE_DESC = "VPN-подписка на 30 дней. {details}"
PAYMENT_SUCCESS = """✅ <b>Оплата прошла успешно!</b>

Тариф <b>{plan}</b> активирован до <b>{expires}</b>.

Нажмите «📦 Мой VPN» чтобы получить ключ подключения."""

PAYMENT_ALREADY_ACTIVE = """ℹ️ У вас уже активна подписка <b>{plan}</b> до {expires}.

Хотите продлить или повысить тариф?"""

# === Referral ===
REFERRAL_INFO = """🎁 <b>Пригласи друга — получи Pro!</b>

Ваша ссылка:
<code>https://t.me/{bot_username}?start=ref_{code}</code>

📊 <b>Статистика:</b>
├ Приглашено: {count}
├ Заработано дней Pro: {earned_days}
└ Статус: {status}

<b>Награды:</b>
├ За регистрацию друга: +{signup_days} дней Pro вам
├ За оплату друга: +{payment_days} дней Pro вам
├ 5 рефералов = месяц Pro
└ 20 рефералов = пожизненный Pro*"""

# === Instructions ===
INSTRUCTIONS_CHOOSE = """📱 <b>Инструкция по подключению</b>

Выберите вашу платформу:"""

INSTRUCTIONS_ANDROID = """📱 <b>Подключение на Android</b>

⚠️ <b>Важно:</b> сначала скопируйте ключ, потом откройте Hiddify!

<b>Шаг 1.</b> Скачайте <a href="https://play.google.com/store/apps/details?id=app.hiddify.com">Hiddify</a> из Google Play

<b>Шаг 2.</b> Вернитесь в бот → «📦 Мой VPN» → «🔑 Получить ключ»

<b>Шаг 3.</b> <b>Нажмите на ключ</b> — он скопируется (появится «Скопировано»)

<b>Шаг 4.</b> Теперь откройте Hiddify → нажмите <b>+</b> (правый верхний угол)

<b>Шаг 5.</b> Нажмите <b>Clipboard</b> — профиль сохранится автоматически

<b>Шаг 6.</b> Нажмите большую кнопку <b>Tap to connect</b>

<b>Шаг 7.</b> Разрешите VPN если Android спросит

✅ Дождитесь статуса <b>Connected</b> — готово!"""

INSTRUCTIONS_IOS = """📱 <b>Подключение на iPhone/iPad</b>

⚠️ <b>Важно:</b> сначала скопируйте ключ, потом откройте Hiddify!

<b>Шаг 1.</b> Скачайте <a href="https://apps.apple.com/app/hiddify-proxy-vpn/id6596777532">Hiddify</a> из App Store (бесплатно)

<b>Шаг 2.</b> Вернитесь в бот → «📦 Мой VPN» → «🔑 Получить ключ»

<b>Шаг 3.</b> <b>Нажмите на ключ</b> — он скопируется (появится «Скопировано»)

<b>Шаг 4.</b> Теперь откройте Hiddify → нажмите <b>+</b> (правый верхний угол)

<b>Шаг 5.</b> Нажмите <b>Clipboard</b> (средняя кнопка) — появится «Profile saved»

<b>Шаг 6.</b> Нажмите большую кнопку <b>Tap to connect</b>

<b>Шаг 7.</b> Разрешите VPN-конфигурацию (iOS спросит один раз)

✅ Дождитесь статуса <b>Connected</b> и значка VPN вверху экрана — готово!"""

INSTRUCTIONS_WINDOWS = """💻 <b>Подключение на Windows</b>

⚠️ <b>Важно:</b> сначала скопируйте ключ, потом откройте Hiddify!

<b>Шаг 1.</b> Скачайте <a href="https://github.com/hiddify/hiddify-app/releases">Hiddify</a> (файл .exe) и установите

<b>Шаг 2.</b> В боте: «📦 Мой VPN» → «🔑 Получить ключ»

<b>Шаг 3.</b> <b>Нажмите на ключ</b> — он скопируется

<b>Шаг 4.</b> Откройте Hiddify → нажмите <b>+</b> → <b>Clipboard</b>

<b>Шаг 5.</b> Нажмите кнопку подключения

✅ Дождитесь статуса <b>Connected</b> — готово!"""

INSTRUCTIONS_MAC = """🍎 <b>Подключение на macOS</b>

⚠️ <b>Важно:</b> сначала скопируйте ключ, потом откройте Hiddify!

<b>Шаг 1.</b> Скачайте <a href="https://github.com/hiddify/hiddify-app/releases">Hiddify</a> (файл .dmg) и установите

<b>Шаг 2.</b> В боте: «📦 Мой VPN» → «🔑 Получить ключ»

<b>Шаг 3.</b> <b>Нажмите на ключ</b> — он скопируется

<b>Шаг 4.</b> Откройте Hiddify → нажмите <b>+</b> → <b>Clipboard</b>

<b>Шаг 5.</b> Нажмите кнопку подключения, разрешите VPN если macOS спросит

✅ Дождитесь статуса <b>Connected</b> — готово!"""

# === Support ===
SUPPORT_PROMPT = """💬 <b>Поддержка StrunaVPN</b>

Опишите вашу проблему в следующем сообщении.
Мы ответим как можно быстрее (обычно до 1 часа)."""

SUPPORT_SENT = """✅ Ваше сообщение отправлено в поддержку.
Ожидайте ответа — мы вам напишем прямо сюда."""

SUPPORT_ADMIN_NEW = """🆘 <b>Новый тикет #{ticket_id}</b>
От: {user_link}
Plan: {plan}

Сообщение:
{message}"""

# === Admin ===
ADMIN_STATS = """📊 <b>StrunaVPN — Статистика</b>

├ Пользователей: <b>{total_users}</b>
├ Активных подписок: <b>{active_subs}</b>
├ Free: {free_users} | Basic: {basic_users} | Pro: {pro_users}
├ Платежей сегодня: <b>{payments_today}</b>
├ Выручка (мес): <b>{revenue_month} Stars</b>
└ Новых за 24ч: <b>{new_24h}</b>"""

# === Notifications ===
NOTIFY_EXPIRING = """⏰ <b>Подписка истекает через {days} дня!</b>

Ваш тариф {plan} действует до {expires}.
Продлите сейчас, чтобы не потерять доступ."""

NOTIFY_TRAFFIC_80 = """⚠️ Вы использовали 80% трафика ({used} из {limit}).

Обновитесь до Pro для безлимитного трафика!"""

NOTIFY_TRAFFIC_100 = """🚫 Трафик исчерпан ({limit}).

Ваш VPN приостановлен до обновления тарифа или начала нового месяца."""

# === Errors ===
ERROR_GENERIC = "❌ Произошла ошибка. Попробуйте позже или напишите в поддержку."
ERROR_MARZBAN = "❌ Ошибка создания VPN-ключа. Мы уже работаем над этим."
BANNED = "🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку."
