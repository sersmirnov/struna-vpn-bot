"""Database operations via asyncpg."""

import asyncpg
import secrets
import string
from datetime import datetime, timedelta, timezone

_pool: asyncpg.Pool | None = None


async def init_pool(dsn: str) -> asyncpg.Pool:
    global _pool
    _pool = await asyncpg.create_pool(dsn, min_size=2, max_size=10)
    return _pool


async def close_pool():
    global _pool
    if _pool:
        await _pool.close()


def _generate_referral_code(length: int = 8) -> str:
    chars = string.ascii_lowercase + string.digits
    return "".join(secrets.choice(chars) for _ in range(length))


# ==================== USERS ====================

async def get_user(telegram_id: int) -> asyncpg.Record | None:
    return await _pool.fetchrow(
        "SELECT * FROM users WHERE telegram_id = $1", telegram_id
    )


async def create_user(
    telegram_id: int,
    username: str | None = None,
    first_name: str | None = None,
    language_code: str = "ru",
    referrer_id: int | None = None,
) -> asyncpg.Record:
    referral_code = _generate_referral_code()
    # Ensure uniqueness
    while await _pool.fetchval(
        "SELECT 1 FROM users WHERE referral_code = $1", referral_code
    ):
        referral_code = _generate_referral_code()

    return await _pool.fetchrow(
        """INSERT INTO users (telegram_id, username, first_name, language_code, 
                              referrer_id, referral_code)
           VALUES ($1, $2, $3, $4, $5, $6)
           ON CONFLICT (telegram_id) DO UPDATE SET 
               username = EXCLUDED.username,
               first_name = EXCLUDED.first_name
           RETURNING *""",
        telegram_id, username, first_name, language_code, referrer_id, referral_code,
    )


async def get_user_by_referral_code(code: str) -> asyncpg.Record | None:
    return await _pool.fetchrow(
        "SELECT * FROM users WHERE referral_code = $1", code
    )


async def update_user_plan(
    telegram_id: int,
    plan: str,
    duration_days: int = 30,
    traffic_limit: int = 0,
    devices_limit: int = 5,
) -> asyncpg.Record:
    now = datetime.now(timezone.utc)
    user = await get_user(telegram_id)

    if plan == "free":
        # Free: always set from now, never extend
        if user and user["plan"] == "free" and user["plan_expires_at"] and user["plan_expires_at"] > now:
            # Already has active free — don't change expiry
            expires = user["plan_expires_at"]
        else:
            expires = now + timedelta(days=duration_days)
    else:
        # Paid: extend from current expiry if active
        if user and user["plan_expires_at"] and user["plan_expires_at"] > now:
            expires = user["plan_expires_at"] + timedelta(days=duration_days)
        else:
            expires = now + timedelta(days=duration_days)

    return await _pool.fetchrow(
        """UPDATE users SET plan = $2, plan_expires_at = $3, 
               traffic_limit = $4, devices_limit = $5, traffic_used = 0
           WHERE telegram_id = $1 RETURNING *""",
        telegram_id, plan, expires, traffic_limit, devices_limit,
    )


async def set_marzban_credentials(
    telegram_id: int, marzban_username: str, sub_url: str
):
    await _pool.execute(
        """UPDATE users SET marzban_username = $2, marzban_sub_url = $3
           WHERE telegram_id = $1""",
        telegram_id, marzban_username, sub_url,
    )


async def add_referral_days(telegram_id: int, days: int):
    """Add Pro days to a user (for referral rewards)."""
    now = datetime.now(timezone.utc)
    user = await get_user(telegram_id)
    if not user:
        return

    current_plan = user["plan"]
    current_expires = user["plan_expires_at"]

    if current_plan in ("basic", "pro") and current_expires and current_expires > now:
        new_expires = current_expires + timedelta(days=days)
    else:
        new_expires = now + timedelta(days=days)

    await _pool.execute(
        """UPDATE users SET plan = 'pro', plan_expires_at = $2,
               traffic_limit = 0, devices_limit = 5
           WHERE telegram_id = $1""",
        telegram_id, new_expires,
    )


async def increment_referral_count(telegram_id: int):
    await _pool.execute(
        "UPDATE users SET referral_count = referral_count + 1 WHERE telegram_id = $1",
        telegram_id,
    )


# ==================== PAYMENTS ====================

async def create_payment(
    telegram_id: int,
    method: str,
    amount: int,
    plan: str,
    duration_days: int = 30,
    amount_usd: float | None = None,
) -> asyncpg.Record:
    return await _pool.fetchrow(
        """INSERT INTO payments (telegram_id, method, amount, plan, duration_days, amount_usd)
           VALUES ($1, $2, $3, $4, $5, $6)
           RETURNING *""",
        telegram_id, method, amount, plan, duration_days, amount_usd,
    )


async def complete_payment(
    payment_id: int,
    telegram_charge_id: str | None = None,
    provider_charge_id: str | None = None,
) -> asyncpg.Record:
    return await _pool.fetchrow(
        """UPDATE payments SET status = 'completed', completed_at = NOW(),
               telegram_charge_id = $2, provider_charge_id = $3
           WHERE id = $1 RETURNING *""",
        payment_id, telegram_charge_id, provider_charge_id,
    )


# ==================== REFERRAL REWARDS ====================

async def create_referral_reward(
    referrer_id: int, referred_id: int, reward_type: str, reward_days: int
):
    await _pool.execute(
        """INSERT INTO referral_rewards (referrer_id, referred_id, reward_type, reward_days)
           VALUES ($1, $2, $3, $4)""",
        referrer_id, referred_id, reward_type, reward_days,
    )


async def get_referral_earned_days(telegram_id: int) -> int:
    result = await _pool.fetchval(
        "SELECT COALESCE(SUM(reward_days), 0) FROM referral_rewards WHERE referrer_id = $1",
        telegram_id,
    )
    return int(result)


# ==================== SUPPORT ====================

async def create_ticket(
    telegram_id: int, message_id: int, admin_message_id: int | None = None
) -> asyncpg.Record:
    return await _pool.fetchrow(
        """INSERT INTO support_tickets (telegram_id, message_id, admin_message_id)
           VALUES ($1, $2, $3) RETURNING *""",
        telegram_id, message_id, admin_message_id,
    )


# ==================== STATS (admin) ====================

async def get_stats() -> dict:
    total = await _pool.fetchval("SELECT COUNT(*) FROM users")
    active = await _pool.fetchval(
        "SELECT COUNT(*) FROM users WHERE plan != 'free' AND plan_expires_at > NOW()"
    )
    free = await _pool.fetchval("SELECT COUNT(*) FROM users WHERE plan = 'free'")
    basic = await _pool.fetchval(
        "SELECT COUNT(*) FROM users WHERE plan = 'basic' AND plan_expires_at > NOW()"
    )
    pro = await _pool.fetchval(
        "SELECT COUNT(*) FROM users WHERE plan = 'pro' AND plan_expires_at > NOW()"
    )
    payments_today = await _pool.fetchval(
        "SELECT COUNT(*) FROM payments WHERE status = 'completed' AND completed_at::date = CURRENT_DATE"
    )
    revenue_month = await _pool.fetchval(
        """SELECT COALESCE(SUM(amount), 0) FROM payments 
           WHERE status = 'completed' AND method = 'stars'
           AND completed_at >= DATE_TRUNC('month', NOW())"""
    )
    new_24h = await _pool.fetchval(
        "SELECT COUNT(*) FROM users WHERE created_at > NOW() - INTERVAL '24 hours'"
    )
    return {
        "total_users": total,
        "active_subs": active,
        "free_users": free,
        "basic_users": basic,
        "pro_users": pro,
        "payments_today": payments_today,
        "revenue_month": int(revenue_month),
        "new_24h": new_24h,
    }


# ==================== EXPIRING SUBS ====================

async def get_expiring_users(days: int = 3) -> list[asyncpg.Record]:
    return await _pool.fetch(
        """SELECT * FROM users 
           WHERE plan != 'free' 
           AND plan_expires_at BETWEEN NOW() AND NOW() + $1 * INTERVAL '1 day'""",
        days,
    )
