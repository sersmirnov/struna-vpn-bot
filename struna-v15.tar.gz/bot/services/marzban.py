"""Marzban API client for managing VPN users."""

import httpx
import logging
from datetime import datetime, timezone

from bot.config import settings

logger = logging.getLogger(__name__)

_token: str | None = None
_client: httpx.AsyncClient | None = None


async def init_client():
    global _client
    _client = httpx.AsyncClient(
        base_url=settings.marzban_base_url,
        timeout=30.0,
    )
    await _authenticate()


async def close_client():
    global _client
    if _client:
        await _client.aclose()


async def _authenticate():
    """Get admin token from Marzban."""
    global _token
    try:
        resp = await _client.post(
            "/api/admin/token",
            data={
                "username": settings.marzban_username,
                "password": settings.marzban_password,
            },
        )
        resp.raise_for_status()
        _token = resp.json()["access_token"]
        logger.info("Marzban: authenticated successfully")
    except Exception as e:
        logger.error(f"Marzban auth failed: {e}")
        raise


def _headers() -> dict:
    return {"Authorization": f"Bearer {_token}"}


async def _ensure_auth():
    """Re-authenticate if token is stale."""
    if not _token:
        await _authenticate()


async def create_user(
    username: str,
    traffic_limit_bytes: int = 0,
    expire_timestamp: int | None = None,
    ip_limit: int = 0,
    protocols: list[str] | None = None,
    inbounds: dict | None = None,
) -> dict:
    """
    Create a VPN user in Marzban.
    
    Args:
        username: unique username (e.g., struna_123456789)
        traffic_limit_bytes: 0 = unlimited
        expire_timestamp: Unix timestamp for expiry
        ip_limit: max simultaneous connections (0 = unlimited)
        protocols: e.g., ["vless", "shadowsocks"]
        inbounds: protocol→inbound mapping
    
    Returns:
        User dict with subscription_url, links, etc.
    """
    await _ensure_auth()

    if protocols is None:
        protocols = ["vless"]
    
    if inbounds is None:
        inbounds = {
            "vless": ["VLESS_REALITY"],
        }

    payload = {
        "username": username,
        "proxies": {proto: {} for proto in protocols},
        "inbounds": inbounds,
        "data_limit": traffic_limit_bytes,
        "data_limit_reset_strategy": "month",
        "status": "active",
        "note": f"StrunaVPN user",
    }

    if expire_timestamp:
        payload["expire"] = expire_timestamp
    
    if ip_limit > 0:
        payload["ip_limit"] = ip_limit

    try:
        resp = await _client.post("/api/user", json=payload, headers=_headers())
        if resp.status_code == 409:
            # User already exists, fetch existing
            logger.info(f"Marzban user {username} already exists, fetching")
            return await get_user(username)
        resp.raise_for_status()
        data = resp.json()
        logger.info(f"Marzban: created user {username}")
        return data
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            await _authenticate()
            resp = await _client.post("/api/user", json=payload, headers=_headers())
            resp.raise_for_status()
            return resp.json()
        logger.error(f"Marzban create_user error: {e}")
        raise


async def get_user(username: str) -> dict:
    """Get user info from Marzban."""
    await _ensure_auth()
    resp = await _client.get(f"/api/user/{username}", headers=_headers())
    resp.raise_for_status()
    return resp.json()


async def update_user(
    username: str,
    traffic_limit_bytes: int | None = None,
    expire_timestamp: int | None = None,
    status: str | None = None,
    ip_limit: int | None = None,
) -> dict:
    """Update existing Marzban user."""
    await _ensure_auth()
    payload = {}
    if traffic_limit_bytes is not None:
        payload["data_limit"] = traffic_limit_bytes
    if expire_timestamp is not None:
        payload["expire"] = expire_timestamp
    if status is not None:
        payload["status"] = status
    if ip_limit is not None:
        payload["ip_limit"] = ip_limit

    resp = await _client.put(
        f"/api/user/{username}", json=payload, headers=_headers()
    )
    resp.raise_for_status()
    return resp.json()


async def reset_user_traffic(username: str) -> dict:
    """Reset user's used traffic to 0."""
    await _ensure_auth()
    resp = await _client.post(
        f"/api/user/{username}/reset", headers=_headers()
    )
    resp.raise_for_status()
    return resp.json()


async def delete_user(username: str):
    """Delete a Marzban user."""
    await _ensure_auth()
    resp = await _client.delete(f"/api/user/{username}", headers=_headers())
    resp.raise_for_status()


async def get_subscription_url(username: str) -> str:
    """Get subscription URL for client apps."""
    user = await get_user(username)
    return user.get("subscription_url", "")


async def get_user_links(username: str) -> list[str]:
    """Get VLESS/SS links for manual import."""
    user = await get_user(username)
    return user.get("links", [])


async def get_system_stats() -> dict:
    """Get Marzban system stats (for admin dashboard)."""
    await _ensure_auth()
    resp = await _client.get("/api/system", headers=_headers())
    resp.raise_for_status()
    return resp.json()
