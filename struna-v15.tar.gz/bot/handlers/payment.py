"""Payment handler — Telegram Stars integration."""

import logging
from datetime import datetime, timezone

from aiogram import Router, Bot, F
from aiogram.types import (
    Message, CallbackQuery,
    LabeledPrice, PreCheckoutQuery,
)

from bot.config import settings
from bot.services import database as db
from bot.services import marzban
from bot.keyboards.inline import plans_kb
from bot.keyboards.main import main_menu_kb
from bot.utils.texts import (
    PLANS_LIST, PAYMENT_INVOICE_TITLE, PAYMENT_INVOICE_DESC,
    PAYMENT_SUCCESS, ERROR_GENERIC,
)

logger = logging.getLogger(__name__)
router = Router()

PLANS = {
    "basic": {
        "price_stars": settings.plan_basic_price_stars,
        "devices": settings.plan_basic_devices,
        "duration_days": settings.plan_basic_days,
        "details": "Безлимит, 5 устройств, 30 дней",
    },
}


@router.message(F.text == "🛒 Купить")
async def show_plans(message: Message):
    await message.answer(
        PLANS_LIST.format(basic_price=settings.plan_basic_price_stars),
        reply_markup=plans_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("buy:"))
async def buy_plan(callback: CallbackQuery, bot: Bot):
    plan_name = callback.data.split(":")[1]
    plan = PLANS.get(plan_name)
    if not plan:
        await callback.answer("Тариф не найден", show_alert=True)
        return

    try:
        await bot.send_invoice(
            chat_id=callback.from_user.id,
            title=PAYMENT_INVOICE_TITLE.format(plan="Basic"),
            description=PAYMENT_INVOICE_DESC.format(details=plan["details"]),
            payload=f"plan:{plan_name}:{plan['duration_days']}",
            currency="XTR",
            prices=[LabeledPrice(label="StrunaVPN Basic (30 дней)", amount=plan["price_stars"])],
        )
        await callback.answer()
    except Exception as e:
        logger.error(f"Invoice send error: {e}")
        await callback.answer(ERROR_GENERIC, show_alert=True)


@router.callback_query(F.data == "renew")
async def renew_plan(callback: CallbackQuery, bot: Bot):
    plan = PLANS["basic"]
    await bot.send_invoice(
        chat_id=callback.from_user.id,
        title="Продление StrunaVPN Basic",
        description=f"Продление на 30 дней. {plan['details']}",
        payload=f"plan:basic:{plan['duration_days']}",
        currency="XTR",
        prices=[LabeledPrice(label="Продление Basic (30 дней)", amount=plan["price_stars"])],
    )
    await callback.answer()


async def show_plans_inline(callback: CallbackQuery):
    await callback.message.answer(
        PLANS_LIST.format(basic_price=settings.plan_basic_price_stars),
        reply_markup=plans_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message, bot: Bot):
    payment = message.successful_payment
    tg_user = message.from_user

    parts = payment.invoice_payload.split(":")
    if len(parts) != 3 or parts[0] != "plan":
        logger.error(f"Invalid payment payload: {payment.invoice_payload}")
        return

    plan_name = parts[1]
    duration_days = int(parts[2])
    plan_config = PLANS.get(plan_name)

    if not plan_config:
        logger.error(f"Unknown plan in payment: {plan_name}")
        return

    try:
        db_payment = await db.create_payment(
            telegram_id=tg_user.id,
            method="stars",
            amount=payment.total_amount,
            plan=plan_name,
            duration_days=duration_days,
            amount_usd=round(payment.total_amount * 0.02, 2),
        )

        await db.complete_payment(
            payment_id=db_payment["id"],
            telegram_charge_id=payment.telegram_payment_charge_id,
            provider_charge_id=payment.provider_payment_charge_id,
        )

        user = await db.update_user_plan(
            telegram_id=tg_user.id,
            plan=plan_name,
            duration_days=duration_days,
            traffic_limit=0,  # unlimited
            devices_limit=plan_config["devices"],
        )

        if user["marzban_username"]:
            try:
                expire_ts = int(user["plan_expires_at"].timestamp())
                await marzban.update_user(
                    username=user["marzban_username"],
                    traffic_limit_bytes=0,
                    expire_timestamp=expire_ts,
                    status="active",
                    ip_limit=plan_config["devices"],
                )
            except Exception as e:
                logger.error(f"Marzban update after payment failed: {e}")

        if user["referrer_id"]:
            await db.add_referral_days(user["referrer_id"], settings.referral_payment_days)
            await db.create_referral_reward(
                user["referrer_id"], tg_user.id, "payment", settings.referral_payment_days
            )
            try:
                await bot.send_message(
                    user["referrer_id"],
                    f"Ваш реферал оплатил подписку!\n"
                    f"+{settings.referral_payment_days} дней добавлено.",
                )
            except Exception:
                pass

        expires = user["plan_expires_at"].strftime("%d.%m.%Y")
        await message.answer(
            PAYMENT_SUCCESS.format(plan="Basic", expires=expires),
            reply_markup=main_menu_kb(),
            parse_mode="HTML",
        )

        logger.info(f"Payment: user={tg_user.id}, plan={plan_name}, stars={payment.total_amount}")

    except Exception as e:
        logger.error(f"Payment processing error: {e}", exc_info=True)
        await message.answer(ERROR_GENERIC, parse_mode="HTML")
