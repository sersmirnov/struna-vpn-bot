from pydantic_settings import BaseSettings
from pydantic import field_validator


class Settings(BaseSettings):
    # Telegram
    bot_token: str
    admin_ids: list[int] = []
    channel_id: int = 0
    channel_url: str = ""

    # Database
    database_url: str
    redis_url: str = "redis://localhost:6379"

    # Marzban
    marzban_base_url: str
    marzban_username: str
    marzban_password: str

    # Plans config (Stars prices)
    plan_free_traffic_gb: int = 5
    plan_basic_price_stars: int = 75
    plan_basic_traffic_gb: int = 50
    plan_basic_devices: int = 2
    plan_pro_price_stars: int = 150
    plan_pro_traffic_gb: int = 0  # 0 = unlimited
    plan_pro_devices: int = 5

    # Referral
    referral_signup_days: int = 7
    referral_invited_days: int = 3
    referral_payment_days: int = 14

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

    @field_validator("admin_ids", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        return v


settings = Settings()  # type: ignore[call-arg]
