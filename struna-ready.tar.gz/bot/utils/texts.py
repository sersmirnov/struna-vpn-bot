"""All bot texts / messages. Single source of truth for copy."""


WELCOME = """🎸 <b>Добро пожаловать в StrunaVPN!</b>

Быстрый и надёжный VPN прямо в Telegram.
Обход блокировок в 2 клика — без регистраций и приложений*.

🎁 <b>Бесплатно:</b> 5 GB трафика каждый месяц.

Нажми кнопку ниже, чтобы начать 👇"""

WELCOME_REFERRED = """🎸 <b>Добро пожаловать в StrunaVPN!</b>

Вас пригласил друг — вы получаете <b>{days} дней Pro бесплатно!</b> 🎉

Нажмите кнопку ниже, чтобы получить VPN-ключ 👇"""

# === Main Menu ===
MENU = """🎸 <b>StrunaVPN — Главное меню</b>

Выберите действие:"""

# === Subscription ===
SUB_STATUS_FREE = """📦 <b>Ваша подписка: Free</b>

├ Трафик: {used} / {limit}
├ Устройства: 1
└ Локация: Европа

💡 <i>Обновите до Pro для безлимита и всех локаций!</i>"""

SUB_STATUS_PAID = """📦 <b>Ваша подписка: {plan}</b>

├ Трафик: {used} / {limit}
├ Устройства: {devices}
├ Локации: {locations}
└ Действует до: <b>{expires}</b>"""

SUB_KEY = """🔑 <b>Ваш VPN-ключ:</b>

<code>{key}</code>

☝️ Нажмите на ключ, чтобы скопировать.
Затем вставьте его в приложение (см. «📱 Инструкция»)."""

SUB_NO_KEY = """⚠️ У вас пока нет VPN-ключа.
Нажмите «🔑 Получить ключ» чтобы создать его."""

# === Payment ===
PLANS_LIST = """🛒 <b>Тарифные планы StrunaVPN</b>

┌─ 🆓 <b>Free</b> — бесплатно
│  5 GB/мес, 1 устройство, Европа
│
├─ ⭐ <b>Basic</b> — {basic_price} Stars (~$1.5)
│  50 GB/мес, 2 устройства, 3 локации
│
└─ 💎 <b>Pro</b> — {pro_price} Stars (~$3)
   Безлимит, 5 устройств, все локации

Выберите тариф:"""

PAYMENT_INVOICE_TITLE = "StrunaVPN — {plan}"
PAYMENT_INVOICE_DESC = "VPN-подписка на 30 дней. {details}"
PAYMENT_SUCCESS = """✅ <b>Оплата прошла успешно!</b>

Тариф <b>{plan}</b> активирован до <b>{expires}</b>.

Нажмите «📦 Мой VPN» чтобы получить ключ подключения."""

PAYMENT_ALREADY_ACTIVE = """ℹ️ У вас уже активна подписка <b>{plan}</b> до {expires}.

Хотите продлить или повысить тариф?"""

# === Referral ===
REFERRAL_INFO = """🎁 <b>Пригласи друга — получи Pro!</b>

Ваша ссылка:
<code>https://t.me/{bot_username}?start=ref_{code}</code>

📊 <b>Статистика:</b>
├ Приглашено: {count}
├ Заработано дней Pro: {earned_days}
└ Статус: {status}

<b>Награды:</b>
├ За регистрацию друга: +{signup_days} дней Pro вам
├ За оплату друга: +{payment_days} дней Pro вам
├ 5 рефералов = месяц Pro
└ 20 рефералов = пожизненный Pro*"""

# === Instructions ===
INSTRUCTIONS_CHOOSE = """📱 <b>Инструкция по подключению</b>

Выберите вашу платформу:"""

INSTRUCTIONS_ANDROID = """📱 <b>Подключение на Android</b>

<b>1.</b> Скачайте <a href="https://play.google.com/store/apps/details?id=com.v2ray.ang">v2rayNG</a> из Google Play
   (или <a href="https://github.com/2dust/v2rayNG/releases">APK с GitHub</a>)

<b>2.</b> В боте нажмите «📦 Мой VPN» → «🔑 Получить ключ»

<b>3.</b> Нажмите на ключ чтобы скопировать

<b>4.</b> В v2rayNG нажмите <b>+</b> → <b>Импорт из буфера обмена</b>

<b>5.</b> Нажмите ▶️ для подключения

✅ Готово! Telegram и все сайты работают."""

INSTRUCTIONS_IOS = """📱 <b>Подключение на iPhone/iPad</b>

<b>1.</b> Скачайте <a href="https://apps.apple.com/app/streisand/id6450534064">Streisand</a> из App Store (бесплатно)

<b>2.</b> В боте нажмите «📦 Мой VPN» → «🔑 Получить ключ»

<b>3.</b> Нажмите на ключ чтобы скопировать

<b>4.</b> В Streisand нажмите <b>+</b> → <b>Добавить из буфера</b>

<b>5.</b> Включите подключение

✅ Готово!"""

INSTRUCTIONS_WINDOWS = """💻 <b>Подключение на Windows</b>

<b>1.</b> Скачайте <a href="https://github.com/hiddify/hiddify-app/releases">Hiddify</a>

<b>2.</b> В боте нажмите «📦 Мой VPN» → «🔑 Получить ключ»

<b>3.</b> Скопируйте ключ

<b>4.</b> В Hiddify: <b>Новый профиль</b> → вставьте ключ

<b>5.</b> Нажмите <b>Подключиться</b>

✅ Готово!"""

INSTRUCTIONS_MAC = """🍎 <b>Подключение на macOS</b>

<b>1.</b> Скачайте <a href="https://apps.apple.com/app/streisand/id6450534064">Streisand</a> из App Store

<b>2.</b> В боте: «📦 Мой VPN» → «🔑 Получить ключ» → скопируйте

<b>3.</b> В Streisand: <b>+</b> → <b>Добавить из буфера</b>

<b>4.</b> Включите

✅ Готово!"""

# === Support ===
SUPPORT_PROMPT = """💬 <b>Поддержка StrunaVPN</b>

Опишите вашу проблему в следующем сообщении.
Мы ответим как можно быстрее (обычно до 1 часа)."""

SUPPORT_SENT = """✅ Ваше сообщение отправлено в поддержку.
Ожидайте ответа — мы вам напишем прямо сюда."""

SUPPORT_ADMIN_NEW = """🆘 <b>Новый тикет #{ticket_id}</b>
От: {user_link}
Plan: {plan}

Сообщение:
{message}"""

# === Admin ===
ADMIN_STATS = """📊 <b>StrunaVPN — Статистика</b>

├ Пользователей: <b>{total_users}</b>
├ Активных подписок: <b>{active_subs}</b>
├ Free: {free_users} | Basic: {basic_users} | Pro: {pro_users}
├ Платежей сегодня: <b>{payments_today}</b>
├ Выручка (мес): <b>{revenue_month} Stars</b>
└ Новых за 24ч: <b>{new_24h}</b>"""

# === Notifications ===
NOTIFY_EXPIRING = """⏰ <b>Подписка истекает через {days} дня!</b>

Ваш тариф {plan} действует до {expires}.
Продлите сейчас, чтобы не потерять доступ."""

NOTIFY_TRAFFIC_80 = """⚠️ Вы использовали 80% трафика ({used} из {limit}).

Обновитесь до Pro для безлимитного трафика!"""

NOTIFY_TRAFFIC_100 = """🚫 Трафик исчерпан ({limit}).

Ваш VPN приостановлен до обновления тарифа или начала нового месяца."""

# === Errors ===
ERROR_GENERIC = "❌ Произошла ошибка. Попробуйте позже или напишите в поддержку."
ERROR_MARZBAN = "❌ Ошибка создания VPN-ключа. Мы уже работаем над этим."
BANNED = "🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку."
