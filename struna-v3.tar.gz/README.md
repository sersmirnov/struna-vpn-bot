# 🎸 StrunaVPN — Telegram VPN Bot

VPN-сервис с полным циклом внутри Telegram: покупка, подключение, поддержка.

## Стек
- **Python 3.12** + **aiogram 3.x** (async Telegram bot framework)
- **PostgreSQL** (users, subscriptions, payments, referrals)
- **Redis** (FSM states, rate limiting)
- **Marzban API** (VPN user management, VLESS+Reality)

## Быстрый старт

### 1. Настройка окружения
```bash
cp .env.example .env
# Заполни все переменные в .env
```

### 2. Локальный запуск
```bash
pip install -r requirements.txt
python -m bot
```

### 3. Деплой на Railway
```bash
# Railway подхватит Procfile и requirements.txt автоматически
railway up
```

## Переменные окружения

| Переменная | Описание |
|-----------|----------|
| `BOT_TOKEN` | Токен от @BotFather |
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `MARZBAN_BASE_URL` | URL панели Marzban (https://panel.yourdomain.com) |
| `MARZBAN_USERNAME` | Логин админа Marzban |
| `MARZBAN_PASSWORD` | Пароль админа Marzban |
| `ADMIN_IDS` | Telegram ID админов через запятую |
| `CHANNEL_ID` | ID канала для обязательной подписки |
| `CHANNEL_URL` | Ссылка на канал |

## Структура проекта
```
struna-vpn-bot/
├── bot/
│   ├── __main__.py          # Entry point
│   ├── config.py            # Settings from env
│   ├── handlers/
│   │   ├── start.py         # /start + регистрация
│   │   ├── subscription.py  # Просмотр подписки, получение ключа
│   │   ├── payment.py       # Telegram Stars оплата
│   │   ├── referral.py      # Реферальная программа
│   │   ├── support.py       # Тикеты поддержки
│   │   ├── instructions.py  # Гайды подключения
│   │   └── admin.py         # Админ-панель
│   ├── keyboards/
│   │   ├── main.py          # Главное меню
│   │   └── inline.py        # Инлайн-кнопки
│   ├── services/
│   │   ├── marzban.py       # Marzban API client
│   │   ├── database.py      # DB operations
│   │   └── scheduler.py     # Cron jobs (уведомления, проверки)
│   ├── middlewares/
│   │   └── throttling.py    # Rate limiting
│   └── utils/
│       └── texts.py         # Все тексты бота
├── migrations/
│   └── 001_init.sql         # Схема БД
├── scripts/
│   └── setup_marzban.sh     # Скрипт установки Marzban
├── .env.example
├── requirements.txt
├── Procfile                 # Railway
├── railway.toml             # Railway config
└── Dockerfile               # Альтернативный деплой
```

## Тарифы (по умолчанию)

| Тариф | Цена | Трафик | Устройства |
|-------|------|--------|------------|
| Free | 0 | 5 GB/мес | 1 |
| Basic | 75 Stars (~$1.5) | 50 GB/мес | 2 |
| Pro | 150 Stars (~$3) | Безлимит | 5 |

## Лицензия
Приватный проект.
