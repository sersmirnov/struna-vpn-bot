#!/bin/bash
# ============================================================
# StrunaVPN — Marzban Setup Script
# Run on a fresh Ubuntu 22.04+ VPS
# Usage: bash setup_marzban.sh
# ============================================================

set -e

echo "🎸 StrunaVPN — Marzban Panel Setup"
echo "==================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root (sudo bash setup_marzban.sh)${NC}"
    exit 1
fi

# === 1. System updates ===
echo -e "\n${YELLOW}[1/6] Updating system...${NC}"
apt update -y && apt upgrade -y
apt install -y curl wget git socat cron

# === 2. Install Docker ===
echo -e "\n${YELLOW}[2/6] Installing Docker...${NC}"
if ! command -v docker &>/dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo -e "${GREEN}Docker installed${NC}"
else
    echo -e "${GREEN}Docker already installed${NC}"
fi

# === 3. Install Marzban ===
echo -e "\n${YELLOW}[3/6] Installing Marzban...${NC}"
if [ ! -d "/opt/marzban" ]; then
    bash -c "$(curl -sL https://github.com/Gozargah/Marzban-scripts/raw/master/marzban.sh)" @ install
    echo -e "${GREEN}Marzban installed${NC}"
else
    echo -e "${GREEN}Marzban already installed${NC}"
fi

# === 4. Configure Marzban env ===
echo -e "\n${YELLOW}[4/6] Configuring Marzban...${NC}"

# Generate secure password
ADMIN_PASS=$(openssl rand -hex 16)

cat > /opt/marzban/.env << EOF
UVICORN_HOST = "0.0.0.0"
UVICORN_PORT = 8000

# Dashboard
DASHBOARD_PATH = "/dashboard/"

# Admin credentials
SUDO_USERNAME = "admin"
SUDO_PASSWORD = "${ADMIN_PASS}"

# Database (SQLite for single-panel setup, switch to MySQL for HA)
# SQLALCHEMY_DATABASE_URL = "mysql+pymysql://user:pass@db:3306/marzban"

# Node management
XRAY_JSON = "/var/lib/marzban/xray_config.json"

# Subscription
XRAY_SUBSCRIPTION_URL_PREFIX = ""

# Telegram bot notifications (optional)
# TELEGRAM_API_TOKEN = ""
# TELEGRAM_ADMIN_ID = ""
EOF

# === 5. Configure Xray with VLESS Reality ===
echo -e "\n${YELLOW}[5/6] Configuring VLESS + Reality...${NC}"

# Generate Reality keys
KEYS=$(docker run --rm ghcr.io/xtls/xray-core:latest xray x25519 2>/dev/null || echo "")
if [ -z "$KEYS" ]; then
    echo -e "${YELLOW}Note: Will generate keys on first Marzban start${NC}"
    PRIVATE_KEY="auto"
    PUBLIC_KEY="auto"
else
    PRIVATE_KEY=$(echo "$KEYS" | grep "Private" | awk '{print $3}')
    PUBLIC_KEY=$(echo "$KEYS" | grep "Public" | awk '{print $3}')
fi

# Generate short ID
SHORT_ID=$(openssl rand -hex 4)

mkdir -p /var/lib/marzban

cat > /var/lib/marzban/xray_config.json << XRAYEOF
{
  "log": {
    "loglevel": "warning"
  },
  "inbounds": [
    {
      "tag": "VLESS_REALITY",
      "listen": "0.0.0.0",
      "port": 443,
      "protocol": "vless",
      "settings": {
        "clients": [],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "www.google.com:443",
          "xver": 0,
          "serverNames": [
            "www.google.com",
            "google.com"
          ],
          "privateKey": "${PRIVATE_KEY}",
          "shortIds": [
            "${SHORT_ID}",
            ""
          ]
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": [
          "http",
          "tls",
          "quic"
        ]
      }
    },
    {
      "tag": "SS_TCP",
      "listen": "0.0.0.0",
      "port": 1080,
      "protocol": "shadowsocks",
      "settings": {
        "clients": [],
        "network": "tcp,udp"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "tag": "DIRECT"
    },
    {
      "protocol": "blackhole",
      "tag": "BLOCK"
    }
  ],
  "routing": {
    "rules": [
      {
        "ip": ["geoip:private"],
        "outboundTag": "BLOCK",
        "type": "field"
      },
      {
        "type": "field",
        "protocol": ["bittorrent"],
        "outboundTag": "BLOCK"
      }
    ]
  }
}
XRAYEOF

# === 6. Start Marzban ===
echo -e "\n${YELLOW}[6/6] Starting Marzban...${NC}"
cd /opt/marzban
docker compose up -d

# Wait for startup
sleep 5

# === Done ===
SERVER_IP=$(curl -s ifconfig.me)
echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}🎸 StrunaVPN Marzban Panel is ready!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo -e "Panel URL:  ${YELLOW}http://${SERVER_IP}:8000/dashboard/${NC}"
echo -e "API URL:    ${YELLOW}http://${SERVER_IP}:8000${NC}"
echo -e "Username:   ${YELLOW}admin${NC}"
echo -e "Password:   ${YELLOW}${ADMIN_PASS}${NC}"
echo ""
echo -e "VLESS Reality port: ${YELLOW}443${NC}"
echo -e "Shadowsocks port:   ${YELLOW}1080${NC}"
echo ""
if [ "$PUBLIC_KEY" != "auto" ]; then
    echo -e "Reality Public Key:  ${YELLOW}${PUBLIC_KEY}${NC}"
    echo -e "Reality Short ID:    ${YELLOW}${SHORT_ID}${NC}"
fi
echo ""
echo -e "${RED}⚠️  SAVE THESE CREDENTIALS! They won't be shown again.${NC}"
echo ""
echo -e "Next steps:"
echo -e "1. Set up SSL with: ${YELLOW}marzban tls${NC}"
echo -e "2. Point your domain to ${SERVER_IP}"
echo -e "3. Update .env in the bot with the panel URL and credentials"
echo ""
echo -e "Add Marzban node on another server:"
echo -e "  ${YELLOW}bash setup_node.sh <panel_ip> <cert_file>${NC}"
