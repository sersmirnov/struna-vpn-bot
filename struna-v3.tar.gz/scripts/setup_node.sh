#!/bin/bash
# ============================================================
# StrunaVPN — Marzban Node Setup
# Run on a secondary VPS to add it as a node
# Usage: bash setup_node.sh
# ============================================================

set -e

echo "🎸 StrunaVPN — Node Setup"
echo "========================="

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root${NC}"
    exit 1
fi

# === 1. Install Docker ===
echo -e "\n${YELLOW}[1/3] Installing Docker...${NC}"
if ! command -v docker &>/dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
fi

# === 2. Install Marzban Node ===
echo -e "\n${YELLOW}[2/3] Installing Marzban Node...${NC}"
if [ ! -d "/opt/marzban-node" ]; then
    bash -c "$(curl -sL https://github.com/Gozargah/Marzban-node/raw/master/install.sh)" @ install
fi

# === 3. Configure ===
echo -e "\n${YELLOW}[3/3] Configuring node...${NC}"

cat > /opt/marzban-node/.env << EOF
SERVICE_PORT = 2000
XRAY_API_PORT = 2001

# SSL certificate from Marzban panel
# Copy the certificate from panel: /var/lib/marzban/certs/
SSL_CLIENT_CERT_FILE = "/var/lib/marzban-node/certs/ssl_client_cert.pem"
EOF

mkdir -p /var/lib/marzban-node/certs

NODE_IP=$(curl -s ifconfig.me)

echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}🎸 Node installed!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo -e "Node IP:   ${YELLOW}${NODE_IP}${NC}"
echo -e "API Port:  ${YELLOW}2000${NC}"
echo ""
echo -e "Next steps:"
echo -e "1. On the ${YELLOW}Marzban panel server${NC}, copy the client cert:"
echo -e "   ${YELLOW}cat /var/lib/marzban/certs/ssl_client_cert.pem${NC}"
echo ""
echo -e "2. Paste it on this node at:"
echo -e "   ${YELLOW}/var/lib/marzban-node/certs/ssl_client_cert.pem${NC}"
echo ""
echo -e "3. Start the node:"
echo -e "   ${YELLOW}cd /opt/marzban-node && docker compose up -d${NC}"
echo ""
echo -e "4. Add this node in Marzban dashboard:"
echo -e "   Dashboard → Nodes → Add Node"
echo -e "   Address: ${YELLOW}${NODE_IP}${NC}"
echo -e "   Port: ${YELLOW}2000${NC}"
