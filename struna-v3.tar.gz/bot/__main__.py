"""StrunaVPN Bot — entry point."""

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from bot.config import settings
from bot.services import database as db
from bot.services import marzban
from bot.services.scheduler import setup_scheduler
from bot.middlewares.throttling import ThrottlingMiddleware

# Handlers
from bot.handlers import start, subscription, payment, referral, instructions, support, admin

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger(__name__)


async def on_startup(bot: Bot):
    """Initialize services on startup."""
    logger.info("🎸 StrunaVPN Bot starting...")

    # Init database pool
    await db.init_pool(settings.database_url)
    logger.info("✅ Database connected")

    # Run migrations (in production, use a proper migration tool)
    try:
        pool = db._pool
        with open("migrations/001_init.sql", "r") as f:
            sql = f.read()
        await pool.execute(sql)
        logger.info("✅ Migrations applied")
    except Exception as e:
        logger.warning(f"Migration note: {e}")

    # Init Marzban client
    try:
        await marzban.init_client()
        logger.info("✅ Marzban connected")
    except Exception as e:
        logger.error(f"⚠️ Marzban connection failed: {e}")
        logger.error("Bot will start but VPN key generation won't work until Marzban is available")

    # Setup scheduler
    setup_scheduler(bot)
    logger.info("✅ Scheduler started")

    # Set bot commands
    from aiogram.types import BotCommand
    await bot.set_my_commands([
        BotCommand(command="start", description="🎸 Запустить бота"),
        BotCommand(command="admin", description="🔐 Админ-панель"),
    ])

    me = await bot.me()
    logger.info(f"🎸 StrunaVPN Bot @{me.username} is live!")


async def on_shutdown(bot: Bot):
    """Cleanup on shutdown."""
    logger.info("Shutting down...")
    await db.close_pool()
    await marzban.close_client()


async def main():
    # Create bot and dispatcher
    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())

    # Register startup/shutdown hooks
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    # Register throttling middleware
    dp.message.middleware(ThrottlingMiddleware(settings.redis_url))
    dp.callback_query.middleware(ThrottlingMiddleware(settings.redis_url))

    # Register routers (order matters — first match wins)
    dp.include_router(start.router)
    dp.include_router(payment.router)       # Payment must be before subscription (pre_checkout)
    dp.include_router(subscription.router)
    dp.include_router(referral.router)
    dp.include_router(instructions.router)
    dp.include_router(support.router)
    dp.include_router(admin.router)

    # Start polling
    logger.info("Starting polling...")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
