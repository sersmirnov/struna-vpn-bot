"""Background scheduler for notifications and maintenance."""

import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from aiogram import Bot

from bot.services import database as db
from bot.utils.texts import NOTIFY_EXPIRING
from bot.keyboards.inline import renew_kb

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()


def setup_scheduler(bot: Bot):
    """Register all scheduled jobs."""

    async def notify_expiring_subscriptions():
        """Notify users whose subscription expires in 3 days."""
        try:
            users = await db.get_expiring_users(days=3)
            for user in users:
                try:
                    expires = user["plan_expires_at"].strftime("%d.%m.%Y")
                    await bot.send_message(
                        user["telegram_id"],
                        NOTIFY_EXPIRING.format(
                            days=3,
                            plan=user["plan"].title(),
                            expires=expires,
                        ),
                        reply_markup=renew_kb(),
                        parse_mode="HTML",
                    )
                except Exception as e:
                    logger.warning(f"Failed to notify user {user['telegram_id']}: {e}")
            logger.info(f"Expiring notifications sent: {len(users)}")
        except Exception as e:
            logger.error(f"Scheduler error (expiring): {e}")

    # Run daily at 10:00 UTC
    scheduler.add_job(
        notify_expiring_subscriptions,
        CronTrigger(hour=10, minute=0),
        id="notify_expiring",
        replace_existing=True,
    )

    scheduler.start()
    logger.info("Scheduler started")
