"""Rate-limiting middleware using Redis."""

import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
import redis.asyncio as redis

logger = logging.getLogger(__name__)


class ThrottlingMiddleware(BaseMiddleware):
    """Simple rate limiter: max N messages per user per window."""

    def __init__(self, redis_url: str, rate_limit: int = 5, window: int = 10):
        """
        Args:
            redis_url: Redis connection URL
            rate_limit: max messages per window
            window: window size in seconds
        """
        self.redis = redis.from_url(redis_url, decode_responses=True)
        self.rate_limit = rate_limit
        self.window = window

    async def __call__(
        self,
        handler: Callable[[Message | CallbackQuery, dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: dict[str, Any],
    ) -> Any:
        user_id = event.from_user.id if event.from_user else None
        if not user_id:
            return await handler(event, data)

        key = f"throttle:{user_id}"
        try:
            current = await self.redis.incr(key)
            if current == 1:
                await self.redis.expire(key, self.window)

            if current > self.rate_limit:
                logger.debug(f"Throttled user {user_id}")
                if isinstance(event, CallbackQuery):
                    await event.answer("⏳ Слишком много запросов, подождите немного.", show_alert=True)
                return  # Drop the message
        except Exception as e:
            logger.warning(f"Redis throttle error: {e}")

        return await handler(event, data)
