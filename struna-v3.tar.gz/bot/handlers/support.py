"""Support ticket handler — forwards messages to admin chat."""

import logging

from aiogram import Router, Bot, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from bot.config import settings
from bot.services import database as db
from bot.keyboards.inline import support_reply_kb
from bot.keyboards.main import main_menu_kb
from bot.utils.texts import SUPPORT_PROMPT, SUPPORT_SENT, SUPPORT_ADMIN_NEW

logger = logging.getLogger(__name__)
router = Router()


class SupportStates(StatesGroup):
    waiting_message = State()
    admin_replying = State()


# ==================== USER SIDE ====================

@router.message(F.text == "💬 Поддержка")
async def support_start(message: Message, state: FSMContext):
    await state.set_state(SupportStates.waiting_message)
    await message.answer(SUPPORT_PROMPT, parse_mode="HTML")


@router.message(SupportStates.waiting_message)
async def support_receive_message(message: Message, state: FSMContext, bot: Bot):
    """Receive user's support message and forward to admins."""
    await state.clear()

    user = await db.get_user(message.from_user.id)
    plan = user["plan"] if user else "unknown"
    user_link = (
        f'<a href="tg://user?id={message.from_user.id}">'
        f'{message.from_user.first_name}</a>'
    )

    # Create ticket in DB
    ticket = await db.create_ticket(
        telegram_id=message.from_user.id,
        message_id=message.message_id,
    )

    # Forward to all admins
    for admin_id in settings.admin_list:
        try:
            admin_msg = await bot.send_message(
                admin_id,
                SUPPORT_ADMIN_NEW.format(
                    ticket_id=ticket["id"],
                    user_link=user_link,
                    plan=plan,
                    message=message.text or "[media/file]",
                ),
                reply_markup=support_reply_kb(ticket["id"], message.from_user.id),
                parse_mode="HTML",
            )
        except Exception as e:
            logger.warning(f"Failed to notify admin {admin_id}: {e}")

    await message.answer(SUPPORT_SENT, parse_mode="HTML", reply_markup=main_menu_kb())


# ==================== ADMIN SIDE ====================

@router.callback_query(F.data.startswith("admin_reply:"))
async def admin_reply_start(callback: CallbackQuery, state: FSMContext):
    """Admin clicks 'Reply' on a ticket."""
    if callback.from_user.id not in settings.admin_list:
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return

    parts = callback.data.split(":")
    ticket_id = int(parts[1])
    user_tg_id = int(parts[2])

    await state.update_data(reply_to_user=user_tg_id, ticket_id=ticket_id)
    await state.set_state(SupportStates.admin_replying)

    await callback.message.answer(
        f"✍️ Напишите ответ пользователю (тикет #{ticket_id}):"
    )
    await callback.answer()


@router.message(SupportStates.admin_replying)
async def admin_send_reply(message: Message, state: FSMContext, bot: Bot):
    """Admin sends reply to user."""
    if message.from_user.id not in settings.admin_list:
        return

    data = await state.get_data()
    user_tg_id = data.get("reply_to_user")
    ticket_id = data.get("ticket_id")
    await state.clear()

    if not user_tg_id:
        await message.answer("❌ Ошибка: не найден пользователь.")
        return

    try:
        await bot.send_message(
            user_tg_id,
            f"💬 <b>Ответ поддержки (тикет #{ticket_id}):</b>\n\n{message.text}",
            parse_mode="HTML",
        )
        await message.answer(f"✅ Ответ отправлен пользователю {user_tg_id}")
    except Exception as e:
        await message.answer(f"❌ Не удалось отправить: {e}")
