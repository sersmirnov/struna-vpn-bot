"""Payment handler — Telegram Stars integration."""

import logging
from datetime import datetime, timezone

from aiogram import Router, Bot, F
from aiogram.types import (
    Message, CallbackQuery,
    LabeledPrice, PreCheckoutQuery,
)

from bot.config import settings
from bot.services import database as db
from bot.services import marzban
from bot.keyboards.inline import plans_kb
from bot.keyboards.main import main_menu_kb
from bot.utils.texts import (
    PLANS_LIST, PAYMENT_INVOICE_TITLE, PAYMENT_INVOICE_DESC,
    PAYMENT_SUCCESS, ERROR_GENERIC,
)

logger = logging.getLogger(__name__)
router = Router()

# Plan configs
PLANS = {
    "basic": {
        "price_stars": settings.plan_basic_price_stars,
        "traffic_gb": settings.plan_basic_traffic_gb,
        "devices": settings.plan_basic_devices,
        "duration_days": 30,
        "details": "50 GB, 2 устройства, 3 локации",
    },
    "pro": {
        "price_stars": settings.plan_pro_price_stars,
        "traffic_gb": settings.plan_pro_traffic_gb,
        "devices": settings.plan_pro_devices,
        "duration_days": 30,
        "details": "Безлимит трафика, 5 устройств, все локации",
    },
}


@router.message(F.text == "🛒 Купить")
async def show_plans(message: Message):
    await message.answer(
        PLANS_LIST.format(
            basic_price=settings.plan_basic_price_stars,
            pro_price=settings.plan_pro_price_stars,
        ),
        reply_markup=plans_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("buy:"))
async def buy_plan(callback: CallbackQuery, bot: Bot):
    plan_name = callback.data.split(":")[1]  # basic or pro
    plan = PLANS.get(plan_name)
    if not plan:
        await callback.answer("❌ Тариф не найден", show_alert=True)
        return

    # Send Telegram Stars invoice
    try:
        await bot.send_invoice(
            chat_id=callback.from_user.id,
            title=PAYMENT_INVOICE_TITLE.format(plan=plan_name.title()),
            description=PAYMENT_INVOICE_DESC.format(details=plan["details"]),
            payload=f"plan:{plan_name}:30",  # plan:name:days
            currency="XTR",  # XTR = Telegram Stars
            prices=[LabeledPrice(label=f"StrunaVPN {plan_name.title()}", amount=plan["price_stars"])],
        )
        await callback.answer()
    except Exception as e:
        logger.error(f"Invoice send error: {e}")
        await callback.answer(ERROR_GENERIC, show_alert=True)


@router.callback_query(F.data == "renew")
async def renew_plan(callback: CallbackQuery, bot: Bot):
    """Renew current plan."""
    user = await db.get_user(callback.from_user.id)
    if not user or user["plan"] == "free":
        await show_plans_inline(callback)
        return

    plan_name = user["plan"]
    plan = PLANS.get(plan_name)
    if not plan:
        await show_plans_inline(callback)
        return

    await bot.send_invoice(
        chat_id=callback.from_user.id,
        title=f"Продление StrunaVPN {plan_name.title()}",
        description=f"Продление на 30 дней. {plan['details']}",
        payload=f"plan:{plan_name}:30",
        currency="XTR",
        prices=[LabeledPrice(label=f"Продление {plan_name.title()}", amount=plan["price_stars"])],
    )
    await callback.answer()


@router.callback_query(F.data == "upgrade")
async def upgrade_plan(callback: CallbackQuery):
    """Show plans for upgrade."""
    await show_plans_inline(callback)


async def show_plans_inline(callback: CallbackQuery):
    await callback.message.answer(
        PLANS_LIST.format(
            basic_price=settings.plan_basic_price_stars,
            pro_price=settings.plan_pro_price_stars,
        ),
        reply_markup=plans_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ==================== PAYMENT PROCESSING ====================

@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    """Always approve pre-checkout (Stars are guaranteed by Telegram)."""
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message, bot: Bot):
    """Handle successful Stars payment."""
    payment = message.successful_payment
    tg_user = message.from_user

    # Parse payload
    parts = payment.invoice_payload.split(":")
    if len(parts) != 3 or parts[0] != "plan":
        logger.error(f"Invalid payment payload: {payment.invoice_payload}")
        return

    plan_name = parts[1]
    duration_days = int(parts[2])
    plan_config = PLANS.get(plan_name)

    if not plan_config:
        logger.error(f"Unknown plan in payment: {plan_name}")
        return

    try:
        # Record payment in DB
        traffic_bytes = plan_config["traffic_gb"] * (1024 ** 3) if plan_config["traffic_gb"] > 0 else 0
        
        db_payment = await db.create_payment(
            telegram_id=tg_user.id,
            method="stars",
            amount=payment.total_amount,
            plan=plan_name,
            duration_days=duration_days,
            amount_usd=round(payment.total_amount * 0.02, 2),  # ~$0.02 per Star
        )

        await db.complete_payment(
            payment_id=db_payment["id"],
            telegram_charge_id=payment.telegram_payment_charge_id,
            provider_charge_id=payment.provider_payment_charge_id,
        )

        # Update user plan
        user = await db.update_user_plan(
            telegram_id=tg_user.id,
            plan=plan_name,
            duration_days=duration_days,
            traffic_limit=traffic_bytes,
            devices_limit=plan_config["devices"],
        )

        # Update Marzban user if exists
        if user["marzban_username"]:
            try:
                expire_ts = int(user["plan_expires_at"].timestamp())
                await marzban.update_user(
                    username=user["marzban_username"],
                    traffic_limit_bytes=traffic_bytes,
                    expire_timestamp=expire_ts,
                    status="active",
                )
                await marzban.reset_user_traffic(user["marzban_username"])
            except Exception as e:
                logger.error(f"Marzban update after payment failed: {e}")

        # Check if user was referred — reward referrer on first payment
        if user["referrer_id"]:
            existing_payment_reward = await db.get_referral_earned_days(user["referrer_id"])
            # Only reward once per referred user's first payment
            # (simplified check — in production, track per-pair)
            await db.add_referral_days(user["referrer_id"], settings.referral_payment_days)
            await db.create_referral_reward(
                user["referrer_id"], tg_user.id, "payment", settings.referral_payment_days
            )
            try:
                await bot.send_message(
                    user["referrer_id"],
                    f"💰 Ваш реферал оплатил подписку!\n"
                    f"+{settings.referral_payment_days} дней Pro добавлено.",
                )
            except Exception:
                pass

        # Notify user
        expires = user["plan_expires_at"].strftime("%d.%m.%Y")
        await message.answer(
            PAYMENT_SUCCESS.format(plan=plan_name.title(), expires=expires),
            reply_markup=main_menu_kb(),
            parse_mode="HTML",
        )

        logger.info(
            f"Payment completed: user={tg_user.id}, plan={plan_name}, "
            f"stars={payment.total_amount}"
        )

    except Exception as e:
        logger.error(f"Payment processing error: {e}", exc_info=True)
        await message.answer(ERROR_GENERIC, parse_mode="HTML")
