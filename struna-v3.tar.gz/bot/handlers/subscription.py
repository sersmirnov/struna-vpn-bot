"""Handler for subscription status and VPN key generation."""

import logging
from datetime import datetime, timezone

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from bot.services import database as db
from bot.services import marzban
from bot.config import settings
from bot.keyboards.inline import get_key_kb, plans_kb
from bot.utils.texts import (
    SUB_STATUS_FREE, SUB_STATUS_PAID, SUB_KEY, SUB_NO_KEY, ERROR_MARZBAN,
)

logger = logging.getLogger(__name__)
router = Router()


def _format_bytes(b: int) -> str:
    if b <= 0:
        return "Безлимит"
    gb = b / (1024 ** 3)
    if gb >= 1:
        return f"{gb:.1f} GB"
    mb = b / (1024 ** 2)
    return f"{mb:.0f} MB"


@router.message(F.text == "📦 Мой VPN")
async def my_vpn(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user:
        await message.answer("Нажмите /start чтобы зарегистрироваться.")
        return

    now = datetime.now(timezone.utc)
    plan = user["plan"]
    expires = user["plan_expires_at"]

    # Check if paid plan has expired
    if plan != "free" and (not expires or expires < now):
        plan = "free"

    if plan == "free":
        text = SUB_STATUS_FREE.format(
            used=_format_bytes(user["traffic_used"]),
            limit=_format_bytes(user["traffic_limit"]),
        )
    else:
        traffic_limit = user["traffic_limit"]
        text = SUB_STATUS_PAID.format(
            plan=plan.title(),
            used=_format_bytes(user["traffic_used"]),
            limit=_format_bytes(traffic_limit),
            devices=user["devices_limit"],
            locations="Все" if plan == "pro" else "3 (EU, Asia, US)",
            expires=expires.strftime("%d.%m.%Y") if expires else "—",
        )

    await message.answer(text, reply_markup=get_key_kb(), parse_mode="HTML")


@router.callback_query(F.data == "get_key")
async def get_key(callback: CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    if not user:
        await callback.answer("Нажмите /start", show_alert=True)
        return

    marzban_username = user["marzban_username"]

    # If user already has a Marzban account, fetch existing key
    if marzban_username:
        try:
            links = await marzban.get_user_links(marzban_username)
            if links:
                key = links[0]  # Primary VLESS link
                await callback.message.answer(
                    SUB_KEY.format(key=key),
                    parse_mode="HTML",
                )
                await callback.answer()
                return
        except Exception as e:
            logger.error(f"Failed to fetch Marzban links for {marzban_username}: {e}")

    # Create new Marzban user
    try:
        marzban_username = f"struna_{callback.from_user.id}"

        # Determine traffic limit
        plan = user["plan"]
        now = datetime.now(timezone.utc)
        if plan != "free" and user["plan_expires_at"] and user["plan_expires_at"] > now:
            traffic_bytes = user["traffic_limit"]
            expire_ts = int(user["plan_expires_at"].timestamp())
        else:
            traffic_bytes = settings.plan_free_traffic_gb * (1024 ** 3)
            expire_ts = None  # Free plan doesn't expire, just traffic-limited

        marz_user = await marzban.create_user(
            username=marzban_username,
            traffic_limit_bytes=traffic_bytes,
            expire_timestamp=expire_ts,
        )

        sub_url = marz_user.get("subscription_url", "")
        await db.set_marzban_credentials(
            callback.from_user.id, marzban_username, sub_url
        )

        links = marz_user.get("links", [])
        if links:
            key = links[0]
            await callback.message.answer(
                SUB_KEY.format(key=key),
                parse_mode="HTML",
            )
        else:
            await callback.message.answer(SUB_NO_KEY, parse_mode="HTML")

        await callback.answer()

    except Exception as e:
        logger.error(f"Marzban create error for {callback.from_user.id}: {e}")
        await callback.message.answer(ERROR_MARZBAN, parse_mode="HTML")
        await callback.answer()
