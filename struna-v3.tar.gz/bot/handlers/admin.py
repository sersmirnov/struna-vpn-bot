"""Admin panel handler."""

import logging

from aiogram import Router, Bot, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from bot.config import settings
from bot.services import database as db
from bot.keyboards.main import admin_menu_kb, main_menu_kb
from bot.utils.texts import ADMIN_STATS

logger = logging.getLogger(__name__)
router = Router()


class AdminStates(StatesGroup):
    broadcast_message = State()


def _is_admin(user_id: int) -> bool:
    return user_id in settings.admin_list


@router.message(F.text == "/admin")
async def admin_panel(message: Message):
    if not _is_admin(message.from_user.id):
        return

    await message.answer(
        "🔐 <b>Админ-панель StrunaVPN</b>",
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )


@router.message(F.text == "📊 Статистика")
async def admin_stats(message: Message):
    if not _is_admin(message.from_user.id):
        return

    stats = await db.get_stats()
    await message.answer(
        ADMIN_STATS.format(**stats),
        parse_mode="HTML",
    )


@router.message(F.text == "📢 Рассылка")
async def admin_broadcast_start(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return

    await state.set_state(AdminStates.broadcast_message)
    await message.answer(
        "📢 Отправьте сообщение для рассылки всем пользователям.\n"
        "Поддерживается HTML-разметка.\n\n"
        "Отправьте /cancel для отмены."
    )


@router.message(AdminStates.broadcast_message)
async def admin_broadcast_send(message: Message, state: FSMContext, bot: Bot):
    if not _is_admin(message.from_user.id):
        return

    if message.text == "/cancel":
        await state.clear()
        await message.answer("❌ Рассылка отменена.", reply_markup=admin_menu_kb())
        return

    await state.clear()

    # Fetch all user IDs
    pool = db._pool
    rows = await pool.fetch(
        "SELECT telegram_id FROM users WHERE is_banned = FALSE"
    )

    sent = 0
    failed = 0
    status_msg = await message.answer(f"📤 Рассылка начата... 0/{len(rows)}")

    for i, row in enumerate(rows):
        try:
            await bot.send_message(
                row["telegram_id"],
                message.text,
                parse_mode="HTML",
            )
            sent += 1
        except Exception:
            failed += 1

        # Update progress every 50 users
        if (i + 1) % 50 == 0:
            try:
                await status_msg.edit_text(
                    f"📤 Рассылка... {i + 1}/{len(rows)} (✅ {sent} / ❌ {failed})"
                )
            except Exception:
                pass

    await status_msg.edit_text(
        f"✅ Рассылка завершена!\n"
        f"Отправлено: {sent}\nОшибок: {failed}\nВсего: {len(rows)}"
    )
