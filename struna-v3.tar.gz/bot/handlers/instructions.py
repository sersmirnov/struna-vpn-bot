"""Connection instructions handler."""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from bot.keyboards.inline import instructions_kb
from bot.utils.texts import (
    INSTRUCTIONS_CHOOSE,
    INSTRUCTIONS_ANDROID,
    INSTRUCTIONS_IOS,
    INSTRUCTIONS_WINDOWS,
    INSTRUCTIONS_MAC,
)

router = Router()

INSTRUCTION_MAP = {
    "android": INSTRUCTIONS_ANDROID,
    "ios": INSTRUCTIONS_IOS,
    "windows": INSTRUCTIONS_WINDOWS,
    "mac": INSTRUCTIONS_MAC,
}


@router.message(F.text == "📱 Инструкция")
async def show_instructions(message: Message):
    await message.answer(
        INSTRUCTIONS_CHOOSE,
        reply_markup=instructions_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("instr:"))
async def show_platform_instruction(callback: CallbackQuery):
    platform = callback.data.split(":")[1]
    text = INSTRUCTION_MAP.get(platform, INSTRUCTIONS_ANDROID)
    await callback.message.answer(text, parse_mode="HTML", disable_web_page_preview=True)
    await callback.answer()
