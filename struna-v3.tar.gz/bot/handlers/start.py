"""Handler for /start command — registration + referral."""

import logging

from aiogram import Router, Bot, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, CommandObject

from bot.config import settings
from bot.services import database as db
from bot.services import marzban
from bot.keyboards.main import main_menu_kb
from bot.keyboards.inline import channel_sub_kb
from bot.utils.texts import WELCOME, WELCOME_REFERRED, MENU

logger = logging.getLogger(__name__)
router = Router()


async def _check_channel_subscription(bot: Bot, user_id: int) -> bool:
    """Check if user is subscribed to the channel."""
    if not settings.channel_id:
        return True  # No channel configured, skip check
    try:
        member = await bot.get_chat_member(settings.channel_id, user_id)
        return member.status in ("member", "administrator", "creator")
    except Exception:
        return True  # If check fails, don't block the user


@router.message(CommandStart())
async def cmd_start(message: Message, command: CommandObject, bot: Bot):
    tg_user = message.from_user
    if not tg_user:
        return

    # Check channel subscription
    is_subscribed = await _check_channel_subscription(bot, tg_user.id)
    if not is_subscribed:
        await message.answer(
            "📢 Чтобы использовать бота, подпишитесь на наш канал:",
            reply_markup=channel_sub_kb(settings.channel_url),
        )
        # Store referral arg for after subscription
        return

    # Parse referral code from deep link: /start ref_abc12345
    referrer_id = None
    referrer_user = None
    if command.args and command.args.startswith("ref_"):
        ref_code = command.args[4:]
        referrer_user = await db.get_user_by_referral_code(ref_code)
        if referrer_user and referrer_user["telegram_id"] != tg_user.id:
            referrer_id = referrer_user["telegram_id"]

    # Check if user already exists
    existing = await db.get_user(tg_user.id)

    # Register or update user
    user = await db.create_user(
        telegram_id=tg_user.id,
        username=tg_user.username,
        first_name=tg_user.first_name,
        language_code=tg_user.language_code or "ru",
        referrer_id=referrer_id if not existing else existing["referrer_id"],
    )

    # If new user with referral — apply rewards
    if not existing and referrer_id and referrer_user:
        # Reward referrer
        await db.add_referral_days(referrer_id, settings.referral_signup_days)
        await db.increment_referral_count(referrer_id)
        await db.create_referral_reward(
            referrer_id, tg_user.id, "signup", settings.referral_signup_days
        )
        # Reward invited user
        await db.add_referral_days(tg_user.id, settings.referral_invited_days)
        await db.create_referral_reward(
            referrer_id, tg_user.id, "signup", settings.referral_invited_days
        )
        # Notify referrer
        try:
            await bot.send_message(
                referrer_id,
                f"🎉 По вашей ссылке зарегистрировался новый пользователь!\n"
                f"+{settings.referral_signup_days} дней Pro добавлено.",
            )
        except Exception:
            pass

        await message.answer(
            WELCOME_REFERRED.format(days=settings.referral_invited_days),
            reply_markup=main_menu_kb(),
            parse_mode="HTML",
        )
    else:
        await message.answer(
            WELCOME,
            reply_markup=main_menu_kb(),
            parse_mode="HTML",
        )


@router.callback_query(F.data == "check_sub")
async def check_subscription(callback: CallbackQuery, bot: Bot):
    """Re-check channel subscription after user claims they subscribed."""
    if not callback.from_user:
        return

    is_subscribed = await _check_channel_subscription(bot, callback.from_user.id)
    if is_subscribed:
        await callback.message.delete()
        # Trigger the start flow
        user = await db.get_user(callback.from_user.id)
        if not user:
            user = await db.create_user(
                telegram_id=callback.from_user.id,
                username=callback.from_user.username,
                first_name=callback.from_user.first_name,
            )
        await callback.message.answer(
            WELCOME,
            reply_markup=main_menu_kb(),
            parse_mode="HTML",
        )
    else:
        await callback.answer(
            "❌ Вы ещё не подписались на канал!", show_alert=True
        )


@router.message(F.text == "🔙 Назад в меню")
async def back_to_menu(message: Message):
    await message.answer(MENU, reply_markup=main_menu_kb(), parse_mode="HTML")
