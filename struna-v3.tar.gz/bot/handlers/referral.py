"""Referral program handler."""

import logging

from aiogram import Router, F
from aiogram.types import Message

from bot.services import database as db
from bot.utils.texts import REFERRAL_INFO
from bot.config import settings

logger = logging.getLogger(__name__)
router = Router()


@router.message(F.text == "🎁 Пригласить друга")
async def referral_info(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user:
        await message.answer("Нажмите /start чтобы зарегистрироваться.")
        return

    earned_days = await db.get_referral_earned_days(message.from_user.id)
    count = user["referral_count"]

    # Determine status
    if count >= 20:
        status = "🏆 Пожизненный Pro"
    elif count >= 5:
        status = "⭐ VIP реферер"
    else:
        status = f"До VIP: ещё {5 - count} рефералов"

    bot_me = await message.bot.me()

    await message.answer(
        REFERRAL_INFO.format(
            bot_username=bot_me.username,
            code=user["referral_code"],
            count=count,
            earned_days=earned_days,
            status=status,
            signup_days=settings.referral_signup_days,
            payment_days=settings.referral_payment_days,
        ),
        parse_mode="HTML",
    )
