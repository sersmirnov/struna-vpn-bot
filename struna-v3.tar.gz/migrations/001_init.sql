-- StrunaVPN: Initial database schema
-- Run: psql $DATABASE_URL -f migrations/001_init.sql

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========== USERS ==========
CREATE TABLE IF NOT EXISTS users (
    id              BIGSERIAL PRIMARY KEY,          -- internal id
    telegram_id     BIGINT UNIQUE NOT NULL,         -- telegram user id
    username        VARCHAR(255),
    first_name      VARCHAR(255),
    language_code   VARCHAR(10) DEFAULT 'ru',
    
    -- Subscription
    plan            VARCHAR(20) DEFAULT 'free',     -- free / basic / pro
    plan_expires_at TIMESTAMPTZ,
    traffic_limit   BIGINT DEFAULT 5368709120,      -- 5 GB in bytes
    traffic_used    BIGINT DEFAULT 0,
    devices_limit   INT DEFAULT 1,
    
    -- Marzban
    marzban_username VARCHAR(255) UNIQUE,
    marzban_sub_url  TEXT,                          -- subscription URL for client apps
    
    -- Referral
    referrer_id     BIGINT REFERENCES users(telegram_id),
    referral_code   VARCHAR(20) UNIQUE NOT NULL,
    referral_count  INT DEFAULT 0,
    
    -- Meta
    is_banned       BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_telegram_id ON users(telegram_id);
CREATE INDEX idx_users_referral_code ON users(referral_code);
CREATE INDEX idx_users_plan_expires ON users(plan_expires_at);

-- ========== PAYMENTS ==========
CREATE TABLE IF NOT EXISTS payments (
    id              BIGSERIAL PRIMARY KEY,
    telegram_id     BIGINT NOT NULL REFERENCES users(telegram_id),
    
    -- Payment info
    method          VARCHAR(20) NOT NULL,           -- stars / ton / usdt
    amount          INT NOT NULL,                   -- amount in method units (stars count, etc.)
    amount_usd      DECIMAL(10, 2),                 -- equivalent in USD
    plan            VARCHAR(20) NOT NULL,            -- what was purchased
    duration_days   INT NOT NULL,                    -- 30, 90, 365
    
    -- Telegram payment
    telegram_charge_id  VARCHAR(255),
    provider_charge_id  VARCHAR(255),
    
    -- Status
    status          VARCHAR(20) DEFAULT 'pending',  -- pending / completed / refunded / failed
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    completed_at    TIMESTAMPTZ
);

CREATE INDEX idx_payments_telegram_id ON payments(telegram_id);

-- ========== REFERRAL REWARDS ==========
CREATE TABLE IF NOT EXISTS referral_rewards (
    id              BIGSERIAL PRIMARY KEY,
    referrer_id     BIGINT NOT NULL REFERENCES users(telegram_id),
    referred_id     BIGINT NOT NULL REFERENCES users(telegram_id),
    reward_type     VARCHAR(20) NOT NULL,           -- signup / payment
    reward_days     INT NOT NULL,                   -- days of Pro added
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ========== SUPPORT TICKETS ==========
CREATE TABLE IF NOT EXISTS support_tickets (
    id              BIGSERIAL PRIMARY KEY,
    telegram_id     BIGINT NOT NULL REFERENCES users(telegram_id),
    message_id      INT NOT NULL,                   -- original message id in user chat
    admin_message_id INT,                           -- forwarded message id in admin chat
    status          VARCHAR(20) DEFAULT 'open',     -- open / replied / closed
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ========== FUNCTION: auto-update updated_at ==========
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
