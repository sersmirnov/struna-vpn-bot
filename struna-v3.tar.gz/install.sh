#!/bin/bash
# ============================================================
# 🎸 StrunaVPN — Full Stack Installer
# Ставит ВСЁ на один сервер:
#   Marzban (VPN-панель) + Bot + PostgreSQL + Redis
#
# Ubuntu 22.04+ / Debian 12+
# Рекомендуется: Hetzner CX22 (2 vCPU, 4GB RAM, €4.5/мес)
#
# Использование:
#   sudo bash install.sh
# ============================================================

set -e

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
B='\033[1;34m'; C='\033[0;36m'; N='\033[0m'

echo ""
echo -e "${B}╔═══════════════════════════════════════════════╗${N}"
echo -e "${B}║  🎸 StrunaVPN — Full Stack Installer           ║${N}"
echo -e "${B}║  Marzban + Bot + PostgreSQL + Redis             ║${N}"
echo -e "${B}╚═══════════════════════════════════════════════╝${N}"
echo ""

# ======================== CHECKS ========================
if [ "$EUID" -ne 0 ]; then
    echo -e "${R}❌ Запусти от root: sudo bash install.sh${N}"
    exit 1
fi

# ======================== USER INPUT ========================
echo -e "${Y}📋 Мне нужны 2 вещи от тебя:${N}"
echo ""

read -p "1. Telegram Bot Token (от @BotFather): " BOT_TOKEN
if [ -z "$BOT_TOKEN" ]; then
    echo -e "${R}❌ Токен обязателен${N}"; exit 1
fi

read -p "2. Твой Telegram User ID (число, узнать: @userinfobot): " ADMIN_ID
if [ -z "$ADMIN_ID" ]; then
    echo -e "${R}❌ ID обязателен${N}"; exit 1
fi

echo ""
echo -e "${G}✅ Данные получены. Начинаю установку...${N}"
echo ""

SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
DB_PASS=$(openssl rand -hex 16)
MARZBAN_PASS=$(openssl rand -hex 16)
REDIS_PASS=$(openssl rand -hex 12)

# ======================== 1. SYSTEM ========================
echo -e "${Y}[1/7] Обновляю систему...${N}"
export DEBIAN_FRONTEND=noninteractive
apt update -y -qq
apt upgrade -y -qq
apt install -y -qq curl wget git socat cron python3 python3-pip python3-venv postgresql postgresql-contrib redis-server > /dev/null 2>&1
echo -e "${G}  ✅ Система обновлена${N}"

# ======================== 2. DOCKER ========================
echo -e "${Y}[2/7] Устанавливаю Docker...${N}"
if ! command -v docker &>/dev/null; then
    curl -fsSL https://get.docker.com | sh > /dev/null 2>&1
    systemctl enable docker > /dev/null 2>&1
    systemctl start docker
fi
echo -e "${G}  ✅ Docker готов${N}"

# ======================== 3. POSTGRESQL ========================
echo -e "${Y}[3/7] Настраиваю PostgreSQL...${N}"
systemctl enable postgresql > /dev/null 2>&1
systemctl start postgresql

sudo -u postgres psql -c "CREATE USER strunavpn WITH PASSWORD '${DB_PASS}';" 2>/dev/null || true
sudo -u postgres psql -c "CREATE DATABASE strunavpn OWNER strunavpn;" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE strunavpn TO strunavpn;" 2>/dev/null || true
echo -e "${G}  ✅ PostgreSQL готов (БД: strunavpn)${N}"

# ======================== 4. REDIS ========================
echo -e "${Y}[4/7] Настраиваю Redis...${N}"
sed -i "s/^# requirepass .*/requirepass ${REDIS_PASS}/" /etc/redis/redis.conf
sed -i "s/^requirepass .*/requirepass ${REDIS_PASS}/" /etc/redis/redis.conf
systemctl restart redis-server
systemctl enable redis-server > /dev/null 2>&1
echo -e "${G}  ✅ Redis готов${N}"

# ======================== 5. MARZBAN ========================
echo -e "${Y}[5/7] Устанавливаю Marzban...${N}"

if [ ! -d "/opt/marzban" ]; then
    bash -c "$(curl -sL https://github.com/Gozargah/Marzban-scripts/raw/master/marzban.sh)" @ install > /dev/null 2>&1
fi

# Configure Marzban
cat > /opt/marzban/.env << MENV
UVICORN_HOST = "0.0.0.0"
UVICORN_PORT = 8000
DASHBOARD_PATH = "/dashboard/"
SUDO_USERNAME = "admin"
SUDO_PASSWORD = "${MARZBAN_PASS}"
XRAY_JSON = "/var/lib/marzban/xray_config.json"
XRAY_SUBSCRIPTION_URL_PREFIX = "https://${SERVER_IP}"
MENV

# Generate Reality keys
KEYS_OUTPUT=$(docker run --rm ghcr.io/xtls/xray-core:latest xray x25519 2>/dev/null || echo "")
if [ -n "$KEYS_OUTPUT" ]; then
    PRIVATE_KEY=$(echo "$KEYS_OUTPUT" | grep "Private" | awk '{print $3}')
    PUBLIC_KEY=$(echo "$KEYS_OUTPUT" | grep "Public" | awk '{print $3}')
else
    PRIVATE_KEY="placeholder_generate_manually"
    PUBLIC_KEY="placeholder_generate_manually"
fi
SHORT_ID=$(openssl rand -hex 4)

mkdir -p /var/lib/marzban

cat > /var/lib/marzban/xray_config.json << XRAY
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "tag": "VLESS_REALITY",
      "listen": "0.0.0.0",
      "port": 443,
      "protocol": "vless",
      "settings": { "clients": [], "decryption": "none" },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "www.google.com:443",
          "xver": 0,
          "serverNames": ["www.google.com", "google.com"],
          "privateKey": "${PRIVATE_KEY}",
          "shortIds": ["${SHORT_ID}", ""]
        }
      },
      "sniffing": { "enabled": true, "destOverride": ["http", "tls", "quic"] }
    }
  ],
  "outbounds": [
    { "protocol": "freedom", "tag": "DIRECT" },
    { "protocol": "blackhole", "tag": "BLOCK" }
  ],
  "routing": {
    "rules": [
      { "ip": ["geoip:private"], "outboundTag": "BLOCK", "type": "field" },
      { "type": "field", "protocol": ["bittorrent"], "outboundTag": "BLOCK" }
    ]
  }
}
XRAY

cd /opt/marzban && docker compose up -d > /dev/null 2>&1
sleep 5
echo -e "${G}  ✅ Marzban запущен (порт 8000, VPN на порту 443)${N}"

# ======================== 6. BOT ========================
echo -e "${Y}[6/7] Устанавливаю бота...${N}"

BOT_DIR="/opt/struna-vpn-bot"
mkdir -p ${BOT_DIR}

# Clone or copy bot files
if [ -d "/tmp/struna-vpn-bot/bot" ]; then
    cp -r /tmp/struna-vpn-bot/* ${BOT_DIR}/
else
    echo -e "${Y}  ⚠ Файлы бота не найдены в /tmp/struna-vpn-bot/${N}"
    echo -e "${Y}  Загрузи архив бота и распакуй:${N}"
    echo -e "${C}  scp struna-vpn-bot.tar.gz root@${SERVER_IP}:/tmp/${N}"
    echo -e "${C}  cd /tmp && tar xzf struna-vpn-bot.tar.gz${N}"
    echo -e "${C}  Потом перезапусти: sudo bash install.sh${N}"
    echo ""
    echo -e "${Y}  Или клонируй из git:${N}"
    echo -e "${C}  git clone <your-repo-url> ${BOT_DIR}${N}"
    echo ""
fi

# Create venv and install deps
cd ${BOT_DIR}
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip > /dev/null 2>&1
pip install -r requirements.txt > /dev/null 2>&1
deactivate

# Create .env
cat > ${BOT_DIR}/.env << BOTENV
BOT_TOKEN=${BOT_TOKEN}
ADMIN_IDS=${ADMIN_ID}
CHANNEL_ID=0
CHANNEL_URL=

DATABASE_URL=postgresql://strunavpn:${DB_PASS}@localhost:5432/strunavpn
REDIS_URL=redis://default:${REDIS_PASS}@localhost:6379

MARZBAN_BASE_URL=http://localhost:8000
MARZBAN_USERNAME=admin
MARZBAN_PASSWORD=${MARZBAN_PASS}
BOTENV

# Run migrations
PGPASSWORD=${DB_PASS} psql -U strunavpn -h localhost -d strunavpn -f ${BOT_DIR}/migrations/001_init.sql > /dev/null 2>&1 || true

echo -e "${G}  ✅ Бот установлен в ${BOT_DIR}${N}"

# ======================== 7. SYSTEMD SERVICE ========================
echo -e "${Y}[7/7] Создаю systemd-сервис...${N}"

cat > /etc/systemd/system/strunavpn-bot.service << SVCEOF
[Unit]
Description=StrunaVPN Telegram Bot
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=root
WorkingDirectory=${BOT_DIR}
Environment=PATH=${BOT_DIR}/venv/bin:/usr/bin:/bin
ExecStart=${BOT_DIR}/venv/bin/python -m bot
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable strunavpn-bot > /dev/null 2>&1
systemctl start strunavpn-bot

sleep 3

# Check if bot is running
if systemctl is-active --quiet strunavpn-bot; then
    BOT_STATUS="${G}✅ РАБОТАЕТ${N}"
else
    BOT_STATUS="${R}❌ НЕ ЗАПУСТИЛСЯ (см. логи ниже)${N}"
fi

# ======================== DONE ========================
echo ""
echo -e "${G}╔═══════════════════════════════════════════════╗${N}"
echo -e "${G}║  🎸 StrunaVPN — Установка завершена!           ║${N}"
echo -e "${G}╚═══════════════════════════════════════════════╝${N}"
echo ""
echo -e "${B}═══ Marzban (VPN-панель) ═══${N}"
echo -e "  URL:      ${Y}http://${SERVER_IP}:8000/dashboard/${N}"
echo -e "  Логин:    ${Y}admin${N}"
echo -e "  Пароль:   ${Y}${MARZBAN_PASS}${N}"
echo ""
echo -e "${B}═══ VPN ═══${N}"
echo -e "  VLESS Reality: порт ${Y}443${N}"
if [ "$PUBLIC_KEY" != "placeholder_generate_manually" ]; then
echo -e "  Public Key:    ${Y}${PUBLIC_KEY}${N}"
fi
echo -e "  Short ID:      ${Y}${SHORT_ID}${N}"
echo ""
echo -e "${B}═══ База данных ═══${N}"
echo -e "  PostgreSQL:    strunavpn:${Y}${DB_PASS}${N}@localhost/strunavpn"
echo -e "  Redis:         ${Y}${REDIS_PASS}${N}"
echo ""
echo -e "${B}═══ Бот ═══${N}"
echo -e "  Статус:   ${BOT_STATUS}"
echo -e "  Папка:    ${Y}${BOT_DIR}${N}"
echo -e "  Логи:     ${C}journalctl -u strunavpn-bot -f${N}"
echo ""
echo -e "${B}═══ Полезные команды ═══${N}"
echo -e "  ${C}systemctl restart strunavpn-bot${N}  — перезапустить бота"
echo -e "  ${C}systemctl status strunavpn-bot${N}   — статус бота"
echo -e "  ${C}journalctl -u strunavpn-bot -f${N}   — логи в реалтайме"
echo -e "  ${C}cd /opt/marzban && docker compose logs -f${N} — логи Marzban"
echo ""
echo -e "${R}⚠️  СОХРАНИ ЭТИ ДАННЫЕ! Они больше не покажутся.${N}"
echo ""

# Save credentials to file
cat > /root/strunavpn-credentials.txt << CREDS
=== StrunaVPN Credentials ===
Generated: $(date)
Server IP: ${SERVER_IP}

Marzban Panel: http://${SERVER_IP}:8000/dashboard/
Marzban Login: admin
Marzban Password: ${MARZBAN_PASS}

PostgreSQL: strunavpn:${DB_PASS}@localhost/strunavpn
Redis Password: ${REDIS_PASS}

Reality Public Key: ${PUBLIC_KEY}
Reality Short ID: ${SHORT_ID}

Bot Token: ${BOT_TOKEN}
Admin Telegram ID: ${ADMIN_ID}
CREDS
chmod 600 /root/strunavpn-credentials.txt
echo -e "${G}💾 Креды сохранены в /root/strunavpn-credentials.txt${N}"
echo ""
