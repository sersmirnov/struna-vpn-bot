#!/bin/bash
# StrunaVPN — Quick Setup (run from project root)
set -e
echo "=== StrunaVPN Setup ==="

# Skip what's already installed
echo "[1/4] Checking dependencies..."
which docker > /dev/null 2>&1 || apt install -y docker.io
which psql > /dev/null 2>&1 || apt install -y postgresql postgresql-contrib
which redis-server > /dev/null 2>&1 || apt install -y redis-server
python3 -c "import aiogram" 2>/dev/null || pip3 install aiogram asyncpg redis httpx pydantic pydantic-settings apscheduler magic-filter aiohttp aiofiles --break-system-packages

# DB setup (skip if exists)
echo "[2/4] Setting up database..."
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='strunavpn'" | grep -q 1 || sudo -u postgres psql -c "CREATE USER strunavpn WITH PASSWORD 'strunadb2026';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='strunavpn'" | grep -q 1 || sudo -u postgres psql -c "CREATE DATABASE strunavpn OWNER strunavpn;"
sudo -u postgres psql -d strunavpn -c "SELECT 1 FROM information_schema.tables WHERE table_name='users'" 2>/dev/null | grep -q 1 || sudo -u postgres psql -d strunavpn -f migrations/001_init.sql

# Copy to permanent location
echo "[3/4] Installing bot..."
mkdir -p /opt/strunavpn
cp -r . /opt/strunavpn/
cd /opt/strunavpn

# Create systemd service
echo "[4/4] Creating service..."
cat > /etc/systemd/system/strunavpn.service << 'SVC'
[Unit]
Description=StrunaVPN Bot
After=network.target postgresql.service redis-server.service
[Service]
Type=simple
WorkingDirectory=/opt/strunavpn
ExecStart=/usr/bin/python3 -m bot
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

systemctl daemon-reload
systemctl enable strunavpn
systemctl start strunavpn
sleep 3

if systemctl is-active --quiet strunavpn; then
    echo ""
    echo "=== READY! ==="
    echo "Bot is running. Open Telegram and message your bot."
    echo ""
    echo "Useful commands:"
    echo "  journalctl -u strunavpn -f    (logs)"
    echo "  systemctl restart strunavpn   (restart)"
else
    echo ""
    echo "=== Bot failed to start. Check logs: ==="
    journalctl -u strunavpn --no-pager -n 20
fi
