"""StrunaVPN Dashboard API — lightweight stats endpoint."""

import asyncio
import json
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime, timezone, timedelta
import asyncpg
import httpx

DB_URL = os.getenv("DATABASE_URL", "postgresql://strunavpn:strunadb2026@localhost:5432/strunavpn")
MARZBAN_URL = os.getenv("MARZBAN_BASE_URL", "http://localhost:8000")
MARZBAN_USER = os.getenv("MARZBAN_USERNAME", "admin")
MARZBAN_PASS = os.getenv("MARZBAN_PASSWORD", "")

# Read password from bot .env if not set
if not MARZBAN_PASS:
    try:
        with open("/opt/strunavpn/.env") as f:
            for line in f:
                if line.startswith("MARZBAN_PASSWORD="):
                    MARZBAN_PASS = line.strip().split("=", 1)[1]
    except Exception:
        pass

SERVER_COST_EUR = 7.72
SERVER_TRAFFIC_TB = 20
EUR_RUB = 105


async def get_stats():
    pool = await asyncpg.create_pool(DB_URL, min_size=1, max_size=3)
    
    try:
        # Basic counts
        total = await pool.fetchval("SELECT COUNT(*) FROM users")
        free = await pool.fetchval("SELECT COUNT(*) FROM users WHERE plan = 'free' OR plan_expires_at IS NULL OR plan_expires_at < NOW()")
        basic = await pool.fetchval("SELECT COUNT(*) FROM users WHERE plan = 'basic' AND plan_expires_at > NOW()")
        pro = await pool.fetchval("SELECT COUNT(*) FROM users WHERE plan = 'pro' AND plan_expires_at > NOW()")
        
        new_today = await pool.fetchval("SELECT COUNT(*) FROM users WHERE created_at > NOW() - INTERVAL '24 hours'")
        new_7d = await pool.fetchval("SELECT COUNT(*) FROM users WHERE created_at > NOW() - INTERVAL '7 days'")
        
        keys = await pool.fetchval("SELECT COUNT(*) FROM users WHERE marzban_username IS NOT NULL")
        
        # Payments
        payments_today = await pool.fetchval(
            "SELECT COUNT(*) FROM payments WHERE status = 'completed' AND completed_at::date = CURRENT_DATE"
        )
        revenue_stars = await pool.fetchval(
            """SELECT COALESCE(SUM(amount), 0) FROM payments 
               WHERE status = 'completed' AND method = 'stars'
               AND completed_at >= DATE_TRUNC('month', NOW())"""
        )
        revenue_rub = await pool.fetchval(
            """SELECT COALESCE(SUM(amount), 0) FROM payments 
               WHERE status = 'completed' AND method = 'yoomoney'
               AND completed_at >= DATE_TRUNC('month', NOW())"""
        )
        
        referrals = await pool.fetchval("SELECT COUNT(*) FROM users WHERE referrer_id IS NOT NULL")
        tickets = await pool.fetchval("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'")
        
        # Daily signups (7 days)
        signups_7d = await pool.fetch("""
            SELECT DATE(created_at) as d, COUNT(*) as c
            FROM users
            WHERE created_at > NOW() - INTERVAL '7 days'
            GROUP BY DATE(created_at)
            ORDER BY d
        """)
        
        # Daily revenue (7 days)
        revenue_7d = await pool.fetch("""
            SELECT DATE(completed_at) as d, 
                   SUM(CASE WHEN method = 'stars' THEN amount ELSE 0 END) as stars,
                   SUM(CASE WHEN method = 'yoomoney' THEN amount ELSE 0 END) as rub
            FROM payments
            WHERE status = 'completed' AND completed_at > NOW() - INTERVAL '7 days'
            GROUP BY DATE(completed_at)
            ORDER BY d
        """)
        
        # Users list
        users_list = await pool.fetch("""
            SELECT u.telegram_id, u.username, u.plan, u.traffic_used, u.traffic_limit,
                   u.plan_expires_at, u.marzban_username, u.referral_count, u.created_at,
                   u.devices_limit
            FROM users u
            ORDER BY u.created_at DESC
            LIMIT 100
        """)
        
        # Get Marzban online count
        online = 0
        total_traffic_bytes = 0
        try:
            async with httpx.AsyncClient(base_url=MARZBAN_URL, timeout=10) as client:
                resp = await client.post("/api/admin/token", data={"username": MARZBAN_USER, "password": MARZBAN_PASS})
                token = resp.json()["access_token"]
                headers = {"Authorization": f"Bearer {token}"}
                
                # System stats
                sys_resp = await client.get("/api/system", headers=headers)
                if sys_resp.status_code == 200:
                    sys_data = sys_resp.json()
                    online = sys_data.get("users_active", 0)
                    total_traffic_bytes = sys_data.get("incoming_bandwidth", 0) + sys_data.get("outgoing_bandwidth", 0)
        except Exception as e:
            print(f"Marzban API error: {e}")
        
        traffic_gb = round(total_traffic_bytes / (1024**3), 1) if total_traffic_bytes else 0
        
        # Format signups
        today = datetime.now(timezone.utc).date()
        signups_formatted = []
        for i in range(6, -1, -1):
            d = today - timedelta(days=i)
            count = 0
            for row in signups_7d:
                if row["d"] == d:
                    count = row["c"]
            signups_formatted.append({"d": d.strftime("%d.%m"), "v": count})
        
        # Format revenue
        revenue_formatted = []
        for i in range(6, -1, -1):
            d = today - timedelta(days=i)
            stars = 0
            rub = 0
            for row in revenue_7d:
                if row["d"] == d:
                    stars = int(row["stars"])
                    rub = int(row["rub"])
            revenue_formatted.append({"d": d.strftime("%d.%m"), "stars": stars, "rub": rub})
        
        # Format users
        users_formatted = []
        now = datetime.now(timezone.utc)
        for u in users_list:
            exp = u["plan_expires_at"]
            if u["plan"] != "free" and exp and exp > now:
                status = "active"
            elif u["plan"] == "free" and exp and exp > now:
                status = "active"
            elif exp and exp < now:
                status = "expired"
            else:
                status = "new"
            
            used_gb = round(u["traffic_used"] / (1024**3), 1) if u["traffic_used"] else 0
            lim_gb = round(u["traffic_limit"] / (1024**3), 1) if u["traffic_limit"] else 0
            
            users_formatted.append({
                "tg": u["telegram_id"],
                "u": u["username"],
                "p": u["plan"] or "free",
                "gb": used_gb,
                "lim": lim_gb,
                "exp": exp.strftime("%d.%m") if exp else "-",
                "s": status,
                "r": u["referral_count"] or 0,
                "d": u["devices_limit"] or 1,
                "created": u["created_at"].strftime("%d.%m.%Y") if u["created_at"] else "",
            })
        
        # Cost calculations
        server_rub = SERVER_COST_EUR * EUR_RUB
        gb_cost_rub = server_rub / (SERVER_TRAFFIC_TB * 1024)
        paid = int(basic) + int(pro)
        total_rev = int(revenue_stars) * 1.3 + int(revenue_rub)
        
        return {
            "stats": {
                "total": int(total),
                "keys": int(keys),
                "online": online,
                "free": int(free),
                "basic": int(basic),
                "pro": int(pro),
                "paid": paid,
                "stars": int(revenue_stars),
                "rub": int(revenue_rub),
                "total_rev": round(total_rev),
                "new_today": int(new_today),
                "new_7d": int(new_7d),
                "traffic_gb": traffic_gb,
                "refs": int(referrals),
                "tickets": int(tickets),
            },
            "costs": {
                "server_eur": SERVER_COST_EUR,
                "server_rub": round(server_rub),
                "traffic_tb": SERVER_TRAFFIC_TB,
                "gb_cost_rub": round(gb_cost_rub, 4),
                "per_user_rub": round(server_rub / max(int(total), 1), 1),
                "margin": round(total_rev - server_rub),
            },
            "signups_7d": signups_formatted,
            "revenue_7d": revenue_formatted,
            "users": users_formatted,
        }
    finally:
        await pool.close()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/stats":
            try:
                data = asyncio.run(get_stats())
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps(data, ensure_ascii=False).encode())
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        pass  # Silence logs


if __name__ == "__main__":
    port = 8080
    server = HTTPServer(("127.0.0.1", port), Handler)
    print(f"Dashboard API running on http://localhost:{port}/api/stats")
    server.serve_forever()
