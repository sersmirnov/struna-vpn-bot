"""Handler for subscription status and VPN key generation."""

import logging
from datetime import datetime, timezone

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from bot.services import database as db
from bot.services import marzban
from bot.config import settings
from bot.keyboards.inline import get_key_kb, plans_kb
from bot.utils.texts import (
    SUB_STATUS_FREE, SUB_STATUS_PAID, SUB_KEY_INTRO, SUB_KEY_COPY,
    SUB_KEY_INSTRUCTIONS, SUB_NO_KEY, ERROR_MARZBAN,
)

logger = logging.getLogger(__name__)
router = Router()


def _format_bytes(b: int) -> str:
    if b <= 0:
        return "Безлимит"
    gb = b / (1024 ** 3)
    if gb >= 1:
        return f"{gb:.1f} GB"
    mb = b / (1024 ** 2)
    return f"{mb:.0f} MB"


@router.message(F.text == "📦 Мой VPN")
async def my_vpn(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user:
        await message.answer("Нажмите /start чтобы зарегистрироваться.")
        return

    now = datetime.now(timezone.utc)
    plan = user["plan"]
    expires = user["plan_expires_at"]

    # Check if paid plan has expired
    if plan != "free" and (not expires or expires < now):
        plan = "free"

    if plan == "free":
        expires_str = expires.strftime("%d.%m.%Y") if expires else "—"
        text = SUB_STATUS_FREE.format(expires=expires_str)
    else:
        text = SUB_STATUS_PAID.format(
            plan=plan.title(),
            devices=user["devices_limit"],
            expires=expires.strftime("%d.%m.%Y") if expires else "—",
        )

    await message.answer(text, reply_markup=get_key_kb(), parse_mode="HTML")


async def _send_key(message, key: str):
    """Send VPN key as 3 separate messages for clear UX."""
    await message.answer(SUB_KEY_INTRO, parse_mode="HTML")
    await message.answer(SUB_KEY_COPY.format(key=key), parse_mode="HTML")
    await message.answer(SUB_KEY_INSTRUCTIONS, parse_mode="HTML", disable_web_page_preview=True)


@router.callback_query(F.data == "get_key")
async def get_key(callback: CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    if not user:
        await callback.answer("Нажмите /start", show_alert=True)
        return

    marzban_username = user["marzban_username"]

    # If user already has a Marzban account, fetch existing key
    if marzban_username:
        try:
            links = await marzban.get_user_links(marzban_username)
            if links:
                key = links[0]  # Primary VLESS link
                await _send_key(callback.message, key)
                await callback.answer()
                return
        except Exception as e:
            logger.error(f"Failed to fetch Marzban links for {marzban_username}: {e}")

    # Create new Marzban user
    try:
        marzban_username = f"struna_{callback.from_user.id}"

        plan = user["plan"]
        now = datetime.now(timezone.utc)
        if plan != "free" and user["plan_expires_at"] and user["plan_expires_at"] > now:
            # Paid plan — unlimited traffic, expiry from DB
            traffic_bytes = 0
            expire_ts = int(user["plan_expires_at"].timestamp())
            ip_limit = settings.plan_basic_devices
        else:
            # Free plan — unlimited traffic, 7 days from now
            from datetime import timedelta
            free_expires = now + timedelta(days=settings.plan_free_days)
            traffic_bytes = 0
            expire_ts = int(free_expires.timestamp())
            ip_limit = settings.plan_free_devices
            # Update DB with free expiry
            await db.update_user_plan(
                telegram_id=callback.from_user.id,
                plan="free",
                duration_days=settings.plan_free_days,
                traffic_limit=0,
                devices_limit=settings.plan_free_devices,
            )

        marz_user = await marzban.create_user(
            username=marzban_username,
            traffic_limit_bytes=traffic_bytes,
            expire_timestamp=expire_ts,
            ip_limit=ip_limit,
        )

        sub_url = marz_user.get("subscription_url", "")
        await db.set_marzban_credentials(
            callback.from_user.id, marzban_username, sub_url
        )

        links = marz_user.get("links", [])
        if links:
            key = links[0]
            await _send_key(callback.message, key)
        else:
            await callback.message.answer(SUB_NO_KEY, parse_mode="HTML")

        await callback.answer()

    except Exception as e:
        logger.error(f"Marzban create error for {callback.from_user.id}: {e}")
        await callback.message.answer(ERROR_MARZBAN, parse_mode="HTML")
        await callback.answer()


@router.callback_query(F.data == "activate_free")
async def activate_free(callback: CallbackQuery):
    """Activate free trial — show status and offer to get key."""
    user = await db.get_user(callback.from_user.id)
    if not user:
        await callback.answer("Нажмите /start", show_alert=True)
        return

    now = datetime.now(timezone.utc)
    expires = user["plan_expires_at"]

    # If no expiry set yet — this is a new free user
    if not expires or (user["plan"] == "free" and expires < now):
        from datetime import timedelta
        free_expires = now + timedelta(days=settings.plan_free_days)
        await db.update_user_plan(
            telegram_id=callback.from_user.id,
            plan="free",
            duration_days=settings.plan_free_days,
            traffic_limit=0,
            devices_limit=settings.plan_free_devices,
        )
        expires_str = free_expires.strftime("%d.%m.%Y")
        await callback.message.answer(
            f"✅ <b>Free-период активирован!</b>\n\n"
            f"7 дней бесплатного VPN до <b>{expires_str}</b>.\n\n"
            f"Нажмите кнопку ниже чтобы получить ключ 👇",
            parse_mode="HTML",
            reply_markup=get_key_kb(),
        )
    else:
        expires_str = expires.strftime("%d.%m.%Y")
        await callback.message.answer(
            f"ℹ️ У вас уже активен тариф <b>{user['plan'].title()}</b> до <b>{expires_str}</b>.\n\n"
            f"Нажмите кнопку ниже чтобы получить ключ 👇",
            parse_mode="HTML",
            reply_markup=get_key_kb(),
        )

    await callback.answer()
