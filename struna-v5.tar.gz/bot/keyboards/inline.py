from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def plans_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🆓 Free — 7 дней бесплатно", callback_data="get_key")],
            [InlineKeyboardButton(text="⭐ Basic — 75 Stars (~100₽/мес)", callback_data="buy:basic")],
        ]
    )


def get_key_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔑 Получить ключ", callback_data="get_key")],
        ]
    )


def instructions_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🤖 Android", callback_data="instr:android"),
                InlineKeyboardButton(text="🍎 iPhone", callback_data="instr:ios"),
            ],
            [
                InlineKeyboardButton(text="💻 Windows", callback_data="instr:windows"),
                InlineKeyboardButton(text="🍎 macOS", callback_data="instr:mac"),
            ],
        ]
    )


def renew_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔄 Продлить на 30 дней", callback_data="renew")],
        ]
    )


def support_reply_kb(ticket_id: int, user_tg_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(
                text="💬 Ответить",
                callback_data=f"admin_reply:{ticket_id}:{user_tg_id}",
            )],
        ]
    )


def channel_sub_kb(channel_url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📢 Подписаться на канал", url=channel_url)],
            [InlineKeyboardButton(text="✅ Я подписался", callback_data="check_sub")],
        ]
    )
